# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workspace-restoration.spec.cjs >> outline return opens complete current notes and passages without leaving or reselecting the restored study
- Location: tests/workspace-restoration.spec.cjs:297:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('list', { name: 'Notes', exact: true }).getByRole('button')
Expected: 2
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByRole('list', { name: 'Notes', exact: true }).getByRole('button') with timeout 5000ms
  - waiting for getByRole('list', { name: 'Notes', exact: true }).getByRole('button')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e5]:
    - generic [ref=f2e6]:
      - generic [ref=f2e7]: Scribes' Well
      - generic [ref=f2e13]:
        - generic [ref=f2e14]: fixture@example.invalid
        - button "Sign out" [ref=f2e18]
  - main [ref=f2e22]:
    - generic [ref=f2e23]:
      - generic [ref=f2e24]:
        - tablist "Workspace tabs" [ref=f2e25]:
          - generic [ref=f2e26]:
            - tab "Genesis 1" [selected] [ref=f2e27]
            - button "Rename tab 1" [ref=f2e28]: Rename
        - button "New workspace tab" [ref=f2e29]: + New tab
      - generic [ref=f2e30]:
        - button "Add reader pane" [ref=f2e31]
        - button "Enter focus mode" [ref=f2e34]: Focus mode
      - navigation "Reader tools" [ref=f2e40]:
        - button "Studies" [active] [pressed] [ref=f2e41]
        - button "Analysis" [ref=f2e42]
        - generic [ref=f2e43]: Study A
      - generic [ref=f2e44]:
        - tabpanel "Genesis 1" [ref=f2e45]:
          - region "Passage 1" [ref=f2e46]:
            - generic [ref=f2e47]:
              - button "Previous chapter" [disabled] [ref=f2e48]
              - 'button "Navigate: Genesis, chapter 1. Open selector." [ref=f2e52]': Genesis א
              - button "Next chapter" [ref=f2e55]
            - region "Chapter text" [ref=f2e58]:
              - list "Verses" [ref=f2e59]:
                - listitem [ref=f2e60]:
                  - generic "Verse 1" [ref=f2e61]: "1"
                  - paragraph [ref=f2e62]:
                    - 'button "Word: בְּרֵאשִׁית" [ref=f2e63] [cursor=pointer]': בְּרֵאשִׁית
        - complementary "Study tools" [ref=f2e64]:
          - region "My studies" [ref=f2e66]:
            - heading "My studies" [level=2] [ref=f2e67]
            - heading "Study A" [level=3] [ref=f2e68]
            - button "Delete study" [ref=f2e69]
            - button "Rename" [ref=f2e70]
            - button "Add note" [ref=f2e71]
            - list "Notes" [ref=f2e72]:
              - listitem [ref=f2e73]:
                - button "Saved note A" [ref=f2e74]
            - region "Collected passages" [ref=f2e75]:
              - heading "Passages" [level=4] [ref=f2e76]
              - button "Add passage" [disabled] [ref=f2e78]
              - button "Add current passage" [disabled] [ref=f2e82]
              - list "Passages"
            - button "Leave study" [ref=f2e85]
```

# Test source

```ts
  201 | 
  202 | // Review loop 1: retain loop 0 assertions and add executable counterexamples.
  203 | for(const shape of ['null study','null note','wrong note ID','wrong note parent','wrong note owner'])test(`loop1 requested ${shape} never exposes a private label`,async({page})=>{
  204 |  await setup(page);await seed(page,publicSetup(1),privateSetup(1));
  205 |  await owner(page,{read:r=>{const isNote=new URL(r.request().url()).pathname.includes('/notes/');return r.fulfill({json:isNote?(shape==='null note'?null:{id:shape==='wrong note ID'?other:note,study_id:shape==='wrong note parent'?other:study,owner_account_id:shape==='wrong note owner'?other:account,revision:'1',value:{document:{version:1,blocks:[]},connections:[],highlights:[]}}):(shape==='null study'?null:{id:study,owner_account_id:account,title:'Owned',revision:'1'})});}});
  206 |  await page.goto('/');await expect(page.getByRole('status').filter({hasText:'Private reading context not restored.'})).toBeVisible();await expect(tabs(page).first()).toHaveText('Genesis 1');expect((await stored(page))[`account:${account}`].tabs[0]).toMatchObject({study,note,label:'Private label 1'});
  207 | });
  208 | test('loop1 eviction Retry repopulates an unchanged successful live projection',async({page})=>{
  209 |  await setup(page);await add(page);await settled(page);const old=(await stored(page)).public;
  210 |  await page.evaluate(async old=>{const {workspaceDatabase}=await import('/src/lib/workspace-storage.ts');await new Promise((resolve,reject)=>{const r=indexedDB.open(workspaceDatabase,1);r.onsuccess=()=>{const db=r.result,tx=db.transaction('metadata','readwrite');tx.objectStore('metadata').put({...old,v:2},'public');tx.oncomplete=()=>{db.close();resolve();};tx.onerror=reject;};});},old);
  211 |  await add(page);await expect(page.getByRole('status').filter({hasText:'Reading setup not remembered.'})).toBeVisible();await page.getByRole('button',{name:'Close tab 3',exact:true}).click();
  212 |  await page.evaluate(async()=>{const {workspaceDatabase}=await import('/src/lib/workspace-storage.ts');await new Promise((resolve,reject)=>{const r=indexedDB.deleteDatabase(workspaceDatabase);r.onsuccess=resolve;r.onerror=reject;});});
  213 |  await page.getByRole('status').filter({hasText:'Reading setup not remembered.'}).getByRole('button',{name:'Retry',exact:true}).click();await settled(page);expect((await stored(page)).public.tabs.map(t=>t.tabKey)).toEqual(old.tabs.map(t=>t.tabKey));
  214 | });
  215 | test('loop1 alternating owners have bounded queued writes and truthful overload failure',async({page})=>{
  216 |  await setup(page);await settled(page);
  217 |  const result=await page.evaluate(async({pub,priv})=>{
  218 |   const m=await import('/src/lib/workspace-storage.ts'),original=IDBDatabase.prototype.transaction;let release;const gate=new Promise(resolve=>release=resolve);let held=false,transactions=0;
  219 |   IDBDatabase.prototype.transaction=function(...args){const tx=original.apply(this,args);if(args[1]==='readwrite')transactions++;if(args[1]==='readwrite'&&!held){held=true;const object=tx.objectStore('metadata');let keep=true;const pump=()=>{const req=object.get('hold');req.onsuccess=()=>{if(keep)pump();};};pump();gate.then(()=>{keep=false;});}return tx;};
  220 |   const writes=Array.from({length:200},(_,i)=>m.writeWorkspace(pub,{...priv,account:i%2?priv.account:'10000000-0000-4000-8000-000000000002'}).then(()=>({ok:true}),()=>({ok:false})));
  221 |   await new Promise(resolve=>setTimeout(resolve,100));release();const results=await Promise.all(writes);IDBDatabase.prototype.transaction=original;
  222 |   return {accepted:results.filter(r=>r.ok).length,rejected:results.filter(r=>!r.ok).length,first:results[0].ok,transactions};
  223 |  },{pub:publicSetup(),priv:privateSetup()});expect(result.first).toBe(true);expect(result.accepted).toBe(9);expect(result.transactions).toBe(9);expect(result.rejected).toBeGreaterThan(0);
  224 | });
  225 | const secondStudy='30000000-0000-4000-8000-000000000002',secondNote='40000000-0000-4000-8000-000000000002';
  226 | const ownedStudy=id=>({id,owner_account_id:account,title:id===study?'Study A':'Study B',revision:'1'});
  227 | const ownedNote=(id,parent=study)=>({id,study_id:parent,owner_account_id:account,revision:'1',value:{document:{version:1,blocks:[{type:'paragraph',direction:'auto',content:[{type:'text',text:id===note?'Saved note A':'Saved note B',marks:[]}]}]},connections:[],highlights:[]}});
  228 | async function selectFirstNote(page){await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'Study A',exact:true}).click();await page.getByRole('button',{name:'Saved note A',exact:true}).click();await expect(page.getByRole('textbox',{name:'Note text',exact:true})).toHaveText('Saved note A');}
  229 | function normalResources(r){const path=new URL(r.request().url()).pathname,parts=path.split('/'),parent=parts[3]==='search'?undefined:parts[3];return r.fulfill({json:path.endsWith('/passages')?{study_id:parent,revision:'1',items:[]}:path.endsWith('/notes')?{items:[ownedNote(note,parent),ownedNote(secondNote,parent)],next_cursor:null}:path.includes('/notes/')?ownedNote(parts.at(-1),parent):parent?ownedStudy(parent):{items:[ownedStudy(study),ownedStudy(secondStudy)],next_cursor:null}});}
  230 | for(const scope of ['study','note'])test(`loop1 delayed A ${scope} denial cannot clear newer live B selection or label`,async({page})=>{
  231 |  await setup(page);await seed(page,publicSetup(),privateSetup());let seen=0,release;const gate=new Promise(resolve=>release=resolve);
  232 |  await owner(page,{read:async r=>{const path=new URL(r.request().url()).pathname;if(path.endsWith(scope==='study'?'/'+study:'/notes/'+note)&&++seen===2){await gate;return r.fulfill({status:404,json:{code:'resource_unavailable'}});}return normalResources(r);}});
  233 |  await page.goto('/');await expect(tabs(page).first()).toHaveText('Private label 1');await expect.poll(()=>!!release).toBe(true);await tabs(page).nth(1).click();await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:scope==='study'?'Study B':'Study A',exact:true}).click();await page.getByRole('button',{name:'Saved note B',exact:true}).click();await page.getByRole('button',{name:'Rename tab 2',exact:true}).click();await page.getByLabel('Tab name',{exact:true}).fill('New live B label');await page.getByRole('dialog',{name:'Rename workspace tab'}).getByRole('button',{name:'Save',exact:true}).click();
  234 |  release();await page.waitForTimeout(450);await expect(tabs(page).nth(1)).toHaveText('New live B label');await expect(page.getByRole('textbox',{name:'Note text',exact:true})).toHaveText('Saved note B');await expect.poll(async()=>{const row=(await stored(page))[`account:${account}`]?.tabs.find(t=>t.tabKey==='saved-1');return row&&{study:row.study,note:row.note,label:row.label};}).toEqual({study:scope==='study'?secondStudy:study,note:secondNote,label:'New live B label'});
  235 | });
  236 | test('loop1 first acknowledged UI selection writes private IDs then automatically restores on reload',async({page})=>{
  237 |  await setup(page);await owner(page,{read:normalResources});await page.goto('/');await selectFirstNote(page);await expect.poll(async()=>{const rows=(await stored(page))[`account:${account}`]?.tabs;return rows?.map(t=>({study:t.study,note:t.note}));}).toEqual([{study,note}]);await page.reload();await expect(page.locator('[aria-label="Note text"]')).toHaveCount(1);await page.getByRole('button',{name:'Analysis',exact:true}).click();await expect(page.getByRole('textbox',{name:'Note text',exact:true})).toHaveText('Saved note A');
  238 | });
  239 | test('loop1 same-owner coalescing bounds retained waiters to64 per pending batch',async({page})=>{
  240 |  await setup(page);await settled(page);const result=await page.evaluate(async({pub,priv})=>{
  241 |  const m=await import('/src/lib/workspace-storage.ts'),original=IDBDatabase.prototype.transaction;let release,held=false;const gate=new Promise(resolve=>release=resolve);
  242 |  IDBDatabase.prototype.transaction=function(...args){const tx=original.apply(this,args);if(args[1]==='readwrite'&&!held){held=true;let keep=true;const pump=()=>{const r=tx.objectStore('metadata').get('hold');r.onsuccess=()=>{if(keep)pump();};};pump();gate.then(()=>keep=false);}return tx;};
  243 |  const writes=Array.from({length:200},()=>m.writeWorkspace(pub,priv).then(()=>true,()=>false));await new Promise(resolve=>setTimeout(resolve,80));release();const results=await Promise.all(writes);IDBDatabase.prototype.transaction=original;return {accepted:results.filter(Boolean).length,first:results[0]};
  244 |  },{pub:publicSetup(),priv:privateSetup()});expect(result).toEqual({accepted:65,first:true});
  245 | });
  246 | async function replacePublic(page,pub){await page.evaluate(async pub=>{const {workspaceDatabase}=await import('/src/lib/workspace-storage.ts');await new Promise((resolve,reject)=>{const r=indexedDB.open(workspaceDatabase,1);r.onsuccess=()=>{const db=r.result,tx=db.transaction('metadata','readwrite');tx.objectStore('metadata').put(pub,'public');tx.oncomplete=()=>{db.close();resolve();};tx.onerror=reject;};r.onerror=reject;});},pub);}
  247 | async function stageDirtyCurrentVictims(page,shared){
  248 |  await setup(page);await seed(page,publicSetup(shared?2:1),privateSetup(shared?2:1));await owner(page,{read:normalResources});await page.goto('/');await expect(tabs(page).first()).toHaveText('Private label 1');if(shared)await expect(tabs(page).nth(1)).toHaveText('Private label 2');
  249 |  await add(page);const newKey=await page.evaluate(()=>history.state.usr.scribeswellReader.tabKey);await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'Leave study',exact:true}).click();await tabs(page).first().click();await page.getByRole('button',{name:'Analysis',exact:true}).click();await page.getByRole('textbox',{name:'Note text',exact:true}).fill('Dirty current-victim input');await expect(page.getByRole('status').filter({hasText:'Changes not saved'})).toBeVisible();await page.locator(`[data-workspace-tab="${newKey}"]`).click();await settled(page);await expect.poll(async()=>(await stored(page)).public.activeTabKey).toBe(newKey);
  250 |  const live=await tabs(page).evaluateAll(nodes=>nodes.map(node=>node.dataset.workspaceTab));await replacePublic(page,{...publicSetup(),v:2});await tabs(page).first().click();await expect(page.getByRole('status').filter({hasText:'Reading setup not remembered.'})).toBeVisible();await page.locator(`[data-workspace-tab="${newKey}"]`).click();
  251 |  const pub=publicSetup(12);pub.tabs=pub.tabs.map((tab,i)=>({...tab,tabKey:`remembered-${i}`,incarnation:`remembered-life-${i}`}));pub.activeTabKey='remembered-0';await replacePublic(page,pub);await page.getByRole('status').filter({hasText:'Reading setup not remembered.'}).getByRole('button',{name:'Retry',exact:true}).click();await expect(page.getByRole('dialog',{name:'Restore remembered reading setups'})).toBeVisible();return live;
  252 | }
  253 | test('loop1 intermediate sole dirty victim choice then Cancel preserves input and tabs',async({page})=>{
  254 |  const live=await stageDirtyCurrentVictims(page,false),dialog=page.getByRole('dialog',{name:'Restore remembered reading setups'});await dialog.getByRole('button',{name:/Close current tab 1:/}).click();await expect(page.getByRole('dialog',{name:'Changes not saved'})).toHaveCount(0);await dialog.getByRole('button',{name:'Cancel',exact:true}).click();expect(await tabs(page).evaluateAll(nodes=>nodes.map(node=>node.dataset.workspaceTab))).toEqual(live);await tabs(page).first().click();if(await page.getByRole('button',{name:'Analysis',exact:true}).getAttribute('aria-pressed')!=='true')await page.getByRole('button',{name:'Analysis',exact:true}).click();await expect(page.getByRole('textbox',{name:'Note text',exact:true})).toHaveText('Dirty current-victim input');
  255 | });
  256 | for(const decision of ['Stay','Close anyway'])test(`loop1 shared dirty staged victims guard final survivors once and ${decision}`,async({page})=>{
  257 |  const live=await stageDirtyCurrentVictims(page,true),dialog=page.getByRole('dialog',{name:'Restore remembered reading setups'});await dialog.getByRole('button',{name:/Close current tab/}).first().click();await expect(page.getByRole('dialog',{name:'Changes not saved'})).toHaveCount(0);await dialog.getByRole('button',{name:/Close current tab/}).first().click();await expect(page.getByRole('dialog',{name:'Changes not saved'})).toHaveCount(0);await dialog.getByRole('button',{name:/Close remembered tab/}).first().click();const exit=page.getByRole('dialog',{name:'Changes not saved'});await expect(exit).toBeVisible();await exit.getByRole('button',{name:decision,exact:true}).click();
  258 |  if(decision==='Stay'){expect(await tabs(page).evaluateAll(nodes=>nodes.map(node=>node.dataset.workspaceTab))).toEqual(live);await tabs(page).first().click();if(await page.getByRole('button',{name:'Analysis',exact:true}).getAttribute('aria-pressed')!=='true')await page.getByRole('button',{name:'Analysis',exact:true}).click();await expect(page.getByRole('textbox',{name:'Note text',exact:true})).toHaveText('Dirty current-victim input');}
  259 |  else {await expect(tabs(page)).toHaveCount(12);for(const key of [live[0],live[2]])await expect(page.locator(`[data-workspace-tab="${key}"]`)).toHaveCount(0);await expect(page.getByRole('button',{name:'Recover note save 1',exact:true})).toBeVisible();}
  260 | });
  261 | test('loop1 overall30s hydration deadline hides unfinished candidates and rejects late responses until Retry',async({page})=>{
  262 |  await setup(page);const priv=privateSetup(6);for(const row of priv.tabs){delete row.study;delete row.note;}await seed(page,publicSetup(6),priv);let requests=[],retry=false;
  263 |  await owner(page,{read:async r=>{if(!retry)await new Promise(resolve=>requests.push(resolve));return r.fulfill({json:{items:[],next_cursor:null}});}});const clockStart=Date.now();await page.clock.install({time:clockStart});await page.clock.pauseAt(clockStart+1000);await page.goto('/');await expect.poll(()=>requests.length).toBe(2);
  264 |  await page.clock.fastForward(14000);requests[0]();requests[1]();await expect(tabs(page).first()).toHaveText('Private label 1');await expect.poll(()=>requests.length).toBe(4);
  265 |  await page.clock.fastForward(14000);requests[2]();requests[3]();await expect(tabs(page).nth(3)).toHaveText('Private label 4');await expect.poll(()=>requests.length).toBe(6);
  266 |  await page.clock.fastForward(2100);await expect(page.getByRole('status').filter({hasText:'Private reading context not restored.'})).toBeVisible();requests[4]();requests[5]();await page.waitForTimeout(100);await expect(tabs(page).nth(4)).toHaveText('Genesis 1');await expect(tabs(page).nth(5)).toHaveText('Genesis 1');
  267 |  retry=true;await page.getByRole('status').filter({hasText:'Private reading context not restored.'}).getByRole('button',{name:'Retry',exact:true}).click();await page.getByRole('dialog',{name:'Restore remembered reading setups'}).getByRole('button',{name:'Restore setups',exact:true}).click();await expect(tabs(page).nth(4)).toHaveText('Private label 5');await expect(tabs(page).nth(5)).toHaveText('Private label 6');
  268 | });
  269 | for(const lifecycle of ['pagehide','visibilitychange'])test(`loop1 ${lifecycle} flushes latest eligible projection before debounce`,async({page})=>{
  270 |  await setup(page);await settled(page);await page.clock.install();await add(page);await page.evaluate(event=>(event==='pagehide'?window:document).dispatchEvent(new Event(event)),lifecycle);await expect.poll(async()=>(await stored(page)).public.tabs.length).toBe(2);
  271 | });
  272 | test('loop1 lifecycle flush is suppressed while a restoration decision is unresolved',async({page})=>{
  273 |  await setup(page);const pub=publicSetup(12);await seed(page,pub);await page.goto('/?book=Gen&chapter=2');await expect(page.getByRole('dialog',{name:'Restore remembered reading setups'})).toBeVisible();await page.evaluate(()=>{document.dispatchEvent(new Event('visibilitychange'));window.dispatchEvent(new Event('pagehide'));});await page.waitForTimeout(400);expect((await stored(page)).public).toEqual(pub);
  274 | });
  275 | test('loop1 actual blocked upgrade times out queued storage open and recovers after contention',async({page})=>{
  276 |  await setup(page);await seed(page);const result=await page.evaluate(async()=>{
  277 |  const m=await import('/src/lib/workspace-storage.ts'),open=()=>new Promise((resolve,reject)=>{const r=indexedDB.open(m.workspaceDatabase,1);r.onsuccess=()=>resolve(r.result);r.onerror=reject;});const blocker=await open();let blocked=false;
  278 |  const upgrade=new Promise((resolve,reject)=>{const r=indexedDB.open(m.workspaceDatabase,2);r.onblocked=()=>blocked=true;r.onerror=reject;r.onsuccess=()=>{r.result.close();resolve();};});
  279 |  while(!blocked)await new Promise(resolve=>setTimeout(resolve,10));let failed=false;try{await m.readWorkspace();}catch{failed=true;}blocker.close();await upgrade;
  280 |  await new Promise((resolve,reject)=>{const r=indexedDB.deleteDatabase(m.workspaceDatabase);r.onsuccess=resolve;r.onerror=reject;});const recovered=await m.readWorkspace();return {blocked,failed,recovered};
  281 |  });expect(result).toEqual({blocked:true,failed:true,recovered:{}});
  282 | });
  283 | test('loop1 asynchronous transaction abort rolls back public and private writes and permits Retry',async({page})=>{
  284 |  await setup(page);await seed(page,publicSetup(),privateSetup());const before=await stored(page);
  285 |  const result=await page.evaluate(async({pub,priv})=>{const m=await import('/src/lib/workspace-storage.ts'),original=IDBObjectStore.prototype.put;let aborted=false;
  286 |  IDBObjectStore.prototype.put=function(value,key){const request=original.call(this,value,key);if(String(key).startsWith('account:'))request.addEventListener('success',()=>{aborted=true;this.transaction.abort();});return request;};let failed=false;
  287 |  try{await m.writeWorkspace({...pub,activeTabKey:'saved-1'},priv);}catch{failed=true;}finally{IDBObjectStore.prototype.put=original;}return {aborted,failed};
  288 |  },{pub:publicSetup(),priv:privateSetup()});expect(result).toEqual({aborted:true,failed:true});expect(await stored(page)).toEqual(before);
  289 |  await page.evaluate(async({pub,priv})=>{const m=await import('/src/lib/workspace-storage.ts');await m.writeWorkspace({...pub,activeTabKey:'saved-1'},priv);},{pub:publicSetup(),priv:privateSetup()});expect((await stored(page)).public.activeTabKey).toBe('saved-1');
  290 | });
  291 | for(const decision of ['Stay','Close anyway'])test(`loop1 sole dirty current victim final installation requires ${decision}`,async({page})=>{
  292 |  const live=await stageDirtyCurrentVictims(page,false),dialog=page.getByRole('dialog',{name:'Restore remembered reading setups'});await dialog.getByRole('button',{name:/Close current tab/}).click();await expect(page.getByRole('dialog',{name:'Changes not saved'})).toHaveCount(0);await dialog.getByRole('button',{name:/Close remembered tab/}).first().click();const exit=page.getByRole('dialog',{name:'Changes not saved'});await expect(exit).toBeVisible();await exit.getByRole('button',{name:decision,exact:true}).click();
  293 |  if(decision==='Stay'){expect(await tabs(page).evaluateAll(nodes=>nodes.map(node=>node.dataset.workspaceTab))).toEqual(live);await tabs(page).first().click();await expect(page.getByRole('textbox',{name:'Note text',exact:true})).toHaveText('Dirty current-victim input');}
  294 |  else {await expect(tabs(page)).toHaveCount(12);await expect(page.locator(`[data-workspace-tab="${live[0]}"]`)).toHaveCount(0);await expect(page.getByRole('button',{name:'Recover note save 1',exact:true})).toBeVisible();}
  295 | });
  296 | 
  297 | test('outline return opens complete current notes and passages without leaving or reselecting the restored study',async({page})=>{
  298 |  await setup(page);let more=0;const third='40000000-0000-4000-8000-000000000003';
  299 |  await owner(page,{read:r=>{const url=new URL(r.request().url());if(url.pathname.endsWith('/notes')){if(url.searchParams.has('cursor')){more++;return r.fulfill({json:{items:[ownedNote(third)],next_cursor:null}});}return r.fulfill({json:{items:[ownedNote(note),ownedNote(secondNote)],next_cursor:'next'}});}if(url.pathname.endsWith('/passages'))return r.fulfill({json:{study_id:study,revision:'1',items:[{id:'50000000-0000-4000-8000-000000000001',reference}]}});return normalResources(r);}});
  300 |  await page.goto('/');await selectFirstNote(page);await expect.poll(async()=>{const rows=(await stored(page))[`account:${account}`]?.tabs;return rows?.map(row=>({study:row.study,note:row.note}));}).toEqual([{study,note}]);await page.reload();await expect(page.locator('[aria-label="Note text"]')).toHaveCount(1);
> 301 |  await page.getByRole('button',{name:'Studies',exact:true}).click();await expect(page.getByRole('list',{name:'Notes',exact:true}).getByRole('button')).toHaveCount(2);await expect(page.getByRole('list',{name:'Passages',exact:true}).getByRole('listitem')).toHaveCount(1);await expect(page.getByRole('button',{name:'Add passage',exact:true})).toBeEnabled();await expect(page.getByRole('button',{name:'Add current passage',exact:true})).toBeEnabled();await page.getByRole('button',{name:'More notes',exact:true}).click();expect(more).toBe(1);await expect(page.getByRole('list',{name:'Notes',exact:true}).getByRole('button')).toHaveCount(3);await page.getByRole('button',{name:'Analysis',exact:true}).click();await expect(page.getByRole('textbox',{name:'Note text',exact:true})).toHaveText('Saved note A');
      |                                                                                                                                                        ^ Error: expect(locator).toHaveCount(expected) failed
  302 | });
  303 | 
```