# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personal-notes.spec.cjs >> note links review: Bold across an owned atom survives save reload
- Location: tests/personal-notes.spec.cjs:529:70

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Untitled study', exact: true })
    - locator resolved to <button class="underline py-2" data-study-id="30000000-0000-4000-8000-000000000001">Untitled study</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - element is not visible
  - retrying click action
    - waiting for element to be visible, enabled and stable
  - element was detached from the DOM, retrying

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - banner [ref=f1e5]:
    - generic [ref=f1e6]:
      - generic [ref=f1e7]: Scribes' Well
      - generic [ref=f1e13]:
        - generic [ref=f1e14]: reader@example.invalid
        - button "Sign out" [ref=f1e18]
  - main [ref=f1e22]:
    - generic [ref=f1e23]:
      - generic [ref=f1e24]:
        - tablist "Workspace tabs" [ref=f1e25]:
          - generic [ref=f1e26]:
            - tab "Genesis 1" [selected] [ref=f1e27]
            - button "Rename tab 1" [ref=f1e28]: Rename
        - button "New workspace tab" [ref=f1e29]: + New tab
      - generic [ref=f1e30]:
        - button "Add reader pane" [ref=f1e31]
        - button "Enter focus mode" [ref=f1e34]: Focus mode
      - navigation "Reader tools" [ref=f1e40]:
        - button "Studies" [active] [pressed] [ref=f1e41]
        - button "Analysis" [ref=f1e42]
        - generic [ref=f1e43]: Untitled study
      - generic [ref=f1e44]:
        - tabpanel "Genesis 1" [ref=f1e45]:
          - region "Passage 1" [ref=f1e46]:
            - generic [ref=f1e47]:
              - button "Previous chapter" [disabled] [ref=f1e48]
              - 'button "Navigate: Genesis, chapter 1. Open selector." [ref=f1e52]': Genesis א
              - button "Next chapter" [disabled] [ref=f1e55]
            - region "Chapter text" [ref=f1e58]:
              - list "Verses" [ref=f1e59]:
                - listitem [ref=f1e60]:
                  - generic "Verse 1" [ref=f1e61]: "1"
                  - paragraph [ref=f1e62]:
                    - 'button "Word: בְּרֵאשִׁית" [ref=f1e63] [cursor=pointer]': בְּרֵאשִׁית
        - complementary "Study tools" [ref=f1e64]:
          - region "My studies" [ref=f1e66]:
            - heading "My studies" [level=2] [ref=f1e67]
            - heading "Untitled study" [level=3] [ref=f1e68]
            - button "Delete study" [ref=f1e69]
            - button "Rename" [ref=f1e70]
            - button "Add note" [ref=f1e71]
            - list "Notes" [ref=f1e72]:
              - listitem [ref=f1e73]:
                - button "Before Genesis 1 after" [ref=f1e74]
            - region "Collected passages" [ref=f1e75]:
              - heading "Passages" [level=4] [ref=f1e76]
              - button "Add passage" [disabled] [ref=f1e78]
              - button "Add current passage" [disabled] [ref=f1e82]
              - list "Passages"
            - button "Leave study" [ref=f1e85]
```

# Test source

```ts
  430 |  else{if(test.info().project.name==='mobile')await page.getByRole('button',{name:'Return to reader',exact:true}).click();await page.getByRole('button',{name:/Navigate:/}).first().click();await page.getByLabel('Passage reference',{exact:true}).fill('Ps110');}
  431 |  options.beforePassagePut=undefined;release();await expect(page.locator('ul[aria-label="Passages"]')).toContainText('Genesis 1');
  432 |  if(destination==='focus')await expect(page.getByLabel('Title',{exact:true})).toBeFocused();else{await expect(page.getByLabel('Passage reference',{exact:true})).toHaveValue('Ps110');await expect(page.getByLabel('Passage reference',{exact:true})).toBeFocused();}
  433 | });
  434 | 
  435 | test('note links: insert at caret retains writing and format2 after final deletion',async({page})=>{
  436 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Before שלום after');await editor.evaluate(el=>{el.focus();const range=document.createRange();range.setStart(el.firstChild,7);range.collapse(true);getSelection().removeAllRanges();getSelection().addRange(range);});
  437 |  await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await page.getByLabel('Passage reference',{exact:true}).fill('Genesis 1:31–2:3');await page.getByLabel('Passage reference',{exact:true}).press('Enter');await expect(editor).toContainText('Before Genesis 1:31–2:3שלום after');
  438 |  await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const put=requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note)).at(-1);expect(put.payload.value.document.version).toBe(2);expect(put.payload.value.document.blocks[0].content.find(i=>i.type==='passage_link').reference.target.end).toEqual({chapter:2,verse:3});expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/passages'))).toHaveLength(0);
  439 |  await editor.locator('[data-note-passage]').evaluate(el=>el.remove());await editor.dispatchEvent('input');await expect.poll(()=>requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note)).at(-1).payload.value.document.blocks[0].content.some(i=>i.type==='passage_link')).toBe(false);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note)).at(-1).payload.value.document.version).toBe(2);
  440 | });
  441 | 
  442 | async function insertNoteReference(page,text){await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await page.getByLabel('Passage reference',{exact:true}).fill(text);await page.getByLabel('Passage reference',{exact:true}).press('Enter');}
  443 | for(const [input,label] of [['תהילים קי:1','Psalms 110:1'],['Genesis 2','Genesis 2'],['Matthew26:63–64','Matthew 26:63–64']])test(`note links: canonical insertion ${input} preserves current reader and note`,async({page})=>{
  444 |  const {requests}=await setup(page);await firstNote(page);const url=page.url(),editor=page.getByLabel('Note text',{exact:true});await editor.fill('My explanation שָׁלוֹם');await editor.evaluate(el=>{el.focus();const r=document.createRange();r.selectNodeContents(el);getSelection().removeAllRanges();getSelection().addRange(r);});await insertNoteReference(page,input);await expect(editor).toContainText('My explanation שָׁלוֹם'+label);expect(page.url()).toBe(url);await expect(editor.locator('[data-note-passage]')).toHaveCount(1);await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='POST'&&r.path.endsWith('/notes'))).toHaveLength(1);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/passages'))).toHaveLength(0);
  445 | });
  446 | test('note links: cancel invalid IME and stale input preserve writing and useful reference input',async({page})=>{
  447 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Useful שָׁלוֹם');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const before=requests.filter(r=>r.method==='PUT').length;
  448 |  await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();const input=page.getByLabel('Passage reference',{exact:true});await input.fill('Ps 2:10–13');await input.press('Enter');await expect(input).toHaveValue('Ps 2:10–13');await expect(editor.locator('[data-note-passage]')).toHaveCount(0);await page.getByRole('button',{name:'Cancel',exact:true}).click();await expect(editor).toBeFocused();expect(requests.filter(r=>r.method==='PUT')).toHaveLength(before);
  449 |  await editor.dispatchEvent('compositionstart');await expect(page.getByRole('button',{name:'Insert passage reference',exact:true})).toBeDisabled();await expect(page.getByRole('button',{name:'Read note',exact:true})).toBeDisabled();await editor.dispatchEvent('compositionend');
  450 |  await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await input.fill('Gen 1');await editor.evaluate(el=>{el.append(document.createTextNode(' later'));el.dispatchEvent(new InputEvent('input',{bubbles:true}));});await input.press('Enter');await expect(input).toHaveValue('Gen 1');await expect(page.getByText('Place the caret in this note, then try inserting the reference again.',{exact:true})).toBeVisible();await expect(editor).toContainText('Useful שָׁלוֹם later');await expect(editor.locator('[data-note-passage]')).toHaveCount(0);await page.getByRole('button',{name:'Cancel',exact:true}).click();await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await expect(input).toHaveValue('Gen 1');await page.getByRole('button',{name:'Cancel',exact:true}).click();
  451 | });
  452 | test('note links: edit click offers Open read click navigates active pane with full range and same lane',async({page})=>{
  453 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Context ');await insertNoteReference(page,'Matthew26:63–64');const atom=editor.locator('[data-note-passage]'),url=page.url();await atom.click();expect(page.url()).toBe(url);await expect(page.getByRole('button',{name:'Open passage',exact:true})).toBeVisible();await page.getByRole('button',{name:'Open passage',exact:true}).click();await expect(page.getByText('Matthew 26:63–64 — Text unavailable',{exact:true})).toBeVisible();if(page.viewportSize().width<768)await page.getByRole('button',{name:'Analysis',exact:true}).click();await expect(editor).toContainText('Context Matthew 26:63–64');const opened=page.url();await page.getByRole('button',{name:'Read note',exact:true}).click();expect(page.url()).toBe(opened);await expect(editor).toHaveAttribute('aria-readonly','true');await atom.click();expect(page.url()).toBe(opened);if(page.viewportSize().width<768)await page.getByRole('button',{name:'Analysis',exact:true}).click();await page.getByRole('button',{name:'Edit note',exact:true}).click();await expect(editor).toHaveAttribute('contenteditable','true');expect(requests.filter(r=>r.method==='POST'&&r.path.endsWith('/notes'))).toHaveLength(1);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/passages'))).toHaveLength(0);
  454 | });
  455 | test('note links: links source marks lists direction plain paste and reload roundtrip',async({page})=>{
  456 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Mixed עברית');await editor.press('ControlOrMeta+End');await page.getByLabel('Paragraph direction',{exact:true}).selectOption('rtl');await page.getByRole('button',{name:'Bullet list',exact:true}).click();await insertNoteReference(page,'Gen 1:31–2:3');await editor.press('End');await editor.press('ControlOrMeta+b');await editor.press('ArrowRight');await editor.press('ControlOrMeta+b');
  457 |  // Use a native clipboard event with HTML and a distinct plain-text value.
  458 |  await editor.evaluate(el=>{el.focus();const d=new DataTransfer();d.setData('text/html','<span data-note-passage="true">forged</span>');d.setData('text/plain',' plain');el.dispatchEvent(new ClipboardEvent('paste',{bubbles:true,clipboardData:d}));});
  459 |  await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const saved=structuredClone(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note)).at(-1).payload.value);expect(saved.document.version).toBe(2);expect(saved.document.blocks.some(b=>b.type==='list')).toBe(true);await page.reload();await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'Untitled study',exact:true}).click();await page.getByRole('list',{name:'Notes',exact:true}).getByRole('button').click();await expect(editor.locator('[data-note-passage]')).toHaveCount(1);await expect(editor).toContainText('Genesis 1:31–2:3');await editor.press('End');await editor.press(' ');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note)).at(-1).payload.value.document.version).toBe(2);
  460 | });
  461 | test('note links: corrupt and foreign atoms stay unsaved and cannot switch to stale reading',async({page})=>{
  462 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await insertNoteReference(page,'Gen 1');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const before=requests.filter(r=>r.method==='PUT').length;await editor.locator('[data-note-passage]').evaluate(el=>{el.textContent='corrupt';el.parentElement.dispatchEvent(new InputEvent('input',{bubbles:true}));});await expect(page.getByRole('status')).toContainText('Changes not saved');await expect(page.getByRole('button',{name:'Read note',exact:true})).toBeDisabled();await page.waitForTimeout(650);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(before);await editor.evaluate(el=>{el.replaceChildren();const s=document.createElement('span');s.dataset.notePassage='true';s.textContent='foreign';s.contentEditable='false';el.append(s);el.dispatchEvent(new InputEvent('input',{bubbles:true}));});await expect(page.getByRole('status')).toContainText('Changes not saved');await page.waitForTimeout(650);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(before);
  463 | });
  464 | test('note links: terminal format refusal pauses saves and retains whole local note',async({page})=>{
  465 |  const options={failPut:409,failPutCode:'note_format_unsupported'};const {requests}=await setup(page,options);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await insertNoteReference(page,'Gen 1');await expect(page.getByRole('alert')).toContainText('Reload to continue editing.');const count=requests.filter(r=>r.method==='PUT').length;await editor.press('End');await editor.press('x');await page.waitForTimeout(650);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(count);await expect(editor).toContainText('Genesis 1');await expect(page.getByRole('status')).toContainText('Changes not saved');await expect(page.getByRole('button',{name:'Retry',exact:true})).toHaveCount(0);
  466 | });
  467 | 
  468 | test('note links: keyboard edit offers Open and keyboard read opens range in active pane only',async({page})=>{
  469 |  const {requests}=await setup(page);await firstNote(page);await addReader(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Keep same note ');await insertNoteReference(page,'Gen 1:31–2:3');const atom=editor.locator('[data-note-passage]'),before=new URL(page.url());await atom.focus();await atom.press('Enter');expect(page.url()).toBe(before.href);await expect(page.getByRole('button',{name:'Open passage',exact:true})).toBeVisible();await page.getByRole('button',{name:'Read note',exact:true}).click();await atom.focus();await atom.press('Space');await expect.poll(()=>readerParams(page.url()).get('compareEndVerse')).toBe('3');const url=new URL(page.url());expect(readerParams(url.href).get('compareVerse')).toBe('31');expect(readerParams(url.href).get('compareEndChapter')).toBe('2');expect(readerParams(url.href).get('book')).toBe(readerParams(before.href).get('book'));expect(readerParams(url.href).get('chapter')).toBe(readerParams(before.href).get('chapter'));if(page.viewportSize().width<768)await page.getByRole('button',{name:'Analysis',exact:true}).click();await expect(editor).toContainText('Keep same note Genesis 1:31–2:3');expect(requests.filter(r=>r.method==='POST'&&r.path.endsWith('/notes'))).toHaveLength(1);
  470 | });
  471 | test('note links: unknown original operation and delayed acknowledgement preserve coherent newer value in Read',async({page})=>{
  472 |  let release;const options={dropPut:true,beforeLookup:()=>new Promise(resolve=>release=resolve)};const {requests}=await setup(page,options);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await insertNoteReference(page,'Gen 1');await expect.poll(()=>Boolean(release)).toBe(true);const first=structuredClone(requests.filter(r=>r.method==='PUT').at(-1).payload);await editor.press('End');await editor.press('x');await page.getByRole('button',{name:'Read note',exact:true}).click();await expect(editor).toContainText('Genesis 1x');await expect(page.getByRole('status')).not.toHaveText('Draft saved');expect(requests.filter(r=>r.method==='PUT')).toHaveLength(1);options.beforeLookup=undefined;release();await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const puts=requests.filter(r=>r.method==='PUT');expect(puts).toHaveLength(2);expect(puts[0].payload).toEqual(first);expect(puts[1].payload.value.document.version).toBe(2);expect(puts[1].payload.operation_id).not.toBe(first.operation_id);await expect(editor.locator('[data-note-passage]')).toHaveCount(1);
  473 | });
  474 | for(const key of ['Backspace','Delete'])test(`note links: ${key} removes atomic inline and retains version2`,async({page})=>{
  475 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await insertNoteReference(page,'Gen 1');await editor.locator('[data-note-passage]').evaluate((el,key)=>{const r=document.createRange();if(key==='Backspace')r.setStartAfter(el);else r.setStartBefore(el);r.collapse(true);el.parentElement.focus();getSelection().removeAllRanges();getSelection().addRange(r);},key);await editor.press(key);await expect(editor.locator('[data-note-passage]')).toHaveCount(0);await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.version).toBe(2);
  476 | });
  477 | test('note links: account replacement clears picker and pending insertion without leaking prior writing',async({page})=>{
  478 |  await setup(page);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('Private prior note');await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await page.getByLabel('Passage reference',{exact:true}).fill('Gen 1');await page.route('**/auth/v1/token*',r=>r.fulfill({json:{...session,user:{...session.user,id:'10000000-0000-4000-8000-000000000002'}}}));await page.evaluate(async()=>{const {supabase}=await import('/src/lib/supabase.ts');await supabase.auth.signOut({scope:'local'});await supabase.auth.signInWithPassword({email:'other@example.invalid',password:'fixture'});});await expect(page.getByLabel('Passage reference',{exact:true})).toHaveCount(0);await expect(page.getByText('Private prior note',{exact:true})).toHaveCount(0);
  479 | });
  480 | test('note links: note switch cancels picker without inserting into replacement note',async({page})=>{
  481 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('First note writing');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await page.getByLabel('Passage reference',{exact:true}).fill('Gen 1');
  482 |  const nextNote='40000000-0000-4000-8000-000000000002';await page.route(`**/api/studies/${study}/notes`,r=>r.request().method()==='POST'?r.fulfill({json:{operation_id:r.request().postDataJSON().operation_id,command:'note.create',study_id:study,note_id:nextNote,revision:'1'}}):r.fallback());await page.route(`**/api/studies/${study}/notes/${nextNote}`,r=>r.fulfill({json:{...attribution,id:nextNote,study_id:study,visibility:'study',revision:'1',value:{document:{version:1,blocks:[]},connections:[],highlights:[]}}}));
  483 |  await page.getByRole('button',{name:'Back to Studies',exact:true}).evaluate(el=>el.click());await page.getByRole('button',{name:'Add note',exact:true}).evaluate(el=>el.click());await expect(page.getByLabel('Passage reference',{exact:true})).toHaveCount(0);await expect(editor).toHaveText('');await expect(editor.locator('[data-note-passage]')).toHaveCount(0);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(1);
  484 | });
  485 | for(const position of [0,6,14])test(`note links: insertion inside source at ${position} preserves source text marks and URL`,async({page})=>{
  486 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('source writing');await editor.press('ControlOrMeta+a');await page.getByRole('button',{name:'Bold',exact:true}).click();await page.getByRole('button',{name:'Link',exact:true}).click();await page.getByLabel('Link URL',{exact:true}).fill('https://example.org');await page.getByRole('button',{name:'Insert link',exact:true}).click();await editor.locator('a').evaluate((el,position)=>{const r=document.createRange();r.setStart(document.createTreeWalker(el,NodeFilter.SHOW_TEXT).nextNode(),position);r.collapse(true);getSelection().removeAllRanges();getSelection().addRange(r);},position);await insertNoteReference(page,'Gen 1');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const content=requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.blocks[0].content;expect(content.map(i=>i.type)).toEqual(position===0?['passage_link','external_link']:position===14?['external_link','passage_link']:['external_link','passage_link','external_link']);const sources=content.filter(i=>i.type==='external_link');expect(sources.flatMap(i=>i.content).map(i=>i.text).join('')).toBe('source writing');expect(sources.every(i=>i.url==='https://example.org'&&i.content.every(t=>JSON.stringify(t.marks)==='["bold"]'))).toBe(true);
  487 | });
  488 | test('note links: caret inside an existing atom resolves after it without corrupting its label',async({page})=>{
  489 |  await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await insertNoteReference(page,'Gen 1');await editor.locator('[data-note-passage]').evaluate(el=>{const r=document.createRange();r.setStart(el.firstChild,3);r.collapse(true);getSelection().removeAllRanges();getSelection().addRange(r);});await insertNoteReference(page,'Gen 2');await expect(editor.locator('[data-note-passage]')).toHaveCount(2);await expect(editor.locator('[data-note-passage]').nth(0)).toHaveText('Genesis 1');await expect(editor.locator('[data-note-passage]').nth(1)).toHaveText('Genesis 2');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();
  490 | });
  491 | test('note links: Read Edit restores caret and keeps ordinary notes in format1',async({page})=>{
  492 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('before after');await editor.evaluate(el=>{const r=document.createRange();r.setStart(el.firstChild,7);r.collapse(true);getSelection().removeAllRanges();getSelection().addRange(r);});const url=page.url();await page.getByRole('button',{name:'Read note',exact:true}).click();await page.getByRole('button',{name:'Edit note',exact:true}).click();await editor.press('x');await expect(editor).toHaveText('before xafter');expect(page.url()).toBe(url);await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.version).toBe(1);
  493 | });
  494 | 
  495 | test('note links patch: direction after atomic insertion targets the actual paragraph',async({page})=>{
  496 |  const {requests}=await setup(page);await firstNote(page);await insertNoteReference(page,'Gen 1');await page.getByLabel('Paragraph direction',{exact:true}).selectOption('rtl');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();await expect.poll(()=>requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.blocks[0].direction).toBe('rtl');
  497 | });
  498 | test('note links patch: deliberate external focus is retained when picker closes',async({page})=>{
  499 |  await setup(page);await firstNote(page);await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await page.getByLabel('Passage reference',{exact:true}).fill('Gen 1');const direction=page.getByLabel('Paragraph direction',{exact:true});await direction.focus();await expect(page.getByLabel('Passage reference',{exact:true})).toHaveCount(0);await expect(direction).toBeFocused();
  500 | });
  501 | test('note links patch: atomic label isolates direction inside opposite-direction text',async({page})=>{
  502 |  await setup(page);await firstNote(page);await page.getByLabel('Paragraph direction',{exact:true}).selectOption('rtl');await insertNoteReference(page,'תהילים קי:1');const atom=page.getByLabel('Note text',{exact:true}).locator('[data-note-passage]');await expect(atom).toHaveAttribute('dir','auto');await expect(atom).toHaveCSS('unicode-bidi','isolate');
  503 | });
  504 | test('note links patch: queued insertion does not steal a deliberately changed focus',async({page})=>{
  505 |  await setup(page);await firstNote(page);await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();const input=page.getByLabel('Passage reference',{exact:true});await input.fill('Gen 1');await input.evaluate(el=>{el.form.requestSubmit();queueMicrotask(()=>document.querySelector('[aria-label="Paragraph direction"]').focus());});await expect(page.getByLabel('Note text',{exact:true}).locator('[data-note-passage]')).toHaveCount(1);await expect(page.getByLabel('Paragraph direction',{exact:true})).toBeFocused();
  506 | });
  507 | test('note links patch: Read hides source-link form and Edit restores its candidate without writing',async({page})=>{
  508 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Source selection');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();await editor.press('ControlOrMeta+a');await page.getByRole('button',{name:'Link',exact:true}).click();await page.getByLabel('Link URL',{exact:true}).fill('https://example.org/source');const before=requests.filter(r=>r.method==='PUT').length;await page.getByRole('button',{name:'Read note',exact:true}).click();await expect(page.getByLabel('Link URL',{exact:true})).toHaveCount(0);await expect(page.getByRole('button',{name:'Insert link',exact:true})).toHaveCount(0);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(before);await page.getByRole('button',{name:'Edit note',exact:true}).click();await expect(page.getByLabel('Link URL',{exact:true})).toHaveValue('https://example.org/source');await page.getByRole('button',{name:'Insert link',exact:true}).click();await expect(editor.locator('a')).toHaveText('Source selection');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();
  509 | });
  510 | 
  511 | for(const position of [null,0,6,14])test(`note links review: native insertion Undo Redo preserves writing and source at ${position}`,async({page})=>{
  512 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.pressSequentially('source writing');await editor.press('ControlOrMeta+z');await expect(editor).toHaveText('');await editor.press('ControlOrMeta+Shift+z');await expect(editor).toHaveText('source writing');if(position!==null){await editor.press('ControlOrMeta+a');await page.getByRole('button',{name:'Link',exact:true}).click();await page.getByLabel('Link URL',{exact:true}).fill('https://example.org/source');await page.getByRole('button',{name:'Insert link',exact:true}).click();await editor.locator('a').evaluate((el,position)=>{const r=document.createRange();r.setStart(document.createTreeWalker(el,NodeFilter.SHOW_TEXT).nextNode(),position);r.collapse(true);getSelection().removeAllRanges();getSelection().addRange(r);},position);}else await editor.press('End');await insertNoteReference(page,'Gen 1');await expect(editor.locator('[data-note-passage]')).toHaveCount(1);await editor.press('ControlOrMeta+z');await expect(editor).toHaveText('source writing');await expect(editor.locator('[data-note-passage]')).toHaveCount(0);if(position!==null)await expect(editor.locator('a')).toHaveText('source writing');await editor.press('ControlOrMeta+Shift+z');await expect(editor.locator('[data-note-passage]')).toHaveCount(1);await expect(editor).toContainText('Genesis 1');await editor.press('End');await editor.press('!');await expect(editor).toContainText('!');await editor.press('ControlOrMeta+z');await expect(editor).not.toContainText('!');await expect(editor.locator('[data-note-passage]')).toHaveCount(1);await editor.press('ControlOrMeta+Shift+z');await expect(editor).toContainText('!');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.version).toBe(2);
  513 | });
  514 | test('note links review: no-caret insertion follows trailing DIV and loose text',async({page})=>{
  515 |  await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.evaluate(el=>{const p=document.createElement('p');p.textContent='First';const div=document.createElement('div');div.textContent='Last block';el.replaceChildren(p,div,document.createTextNode(' trailing'));el.dispatchEvent(new InputEvent('input',{bubbles:true}));getSelection().removeAllRanges();});await insertNoteReference(page,'Gen 1');await expect(editor).toHaveText('FirstLast block trailingGenesis 1');
  516 | });
  517 | test('note links review: interrupted composition replacement accepts insertion only in new lane',async({page})=>{
  518 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.dispatchEvent('compositionstart');await editor.fill('Unfinished old composition');await page.getByRole('button',{name:'Back to Studies',exact:true}).click();const next='40000000-0000-4000-8000-000000000002';await page.route(`**/api/studies/${study}/notes`,r=>r.request().method()==='POST'?r.fulfill({json:{operation_id:r.request().postDataJSON().operation_id,command:'note.create',study_id:study,note_id:next,revision:'1'}}):r.fallback());await page.route(`**/api/studies/${study}/notes/${next}`,r=>r.request().method()==='PUT'?r.fulfill({json:{operation_id:r.request().postDataJSON().operation_id,command:'note.replace',study_id:study,note_id:next,revision:'2'}}):r.fulfill({json:{...attribution,id:next,study_id:study,visibility:'study',revision:'1',value:{document:{version:1,blocks:[]},connections:[],highlights:[]}}}));await page.getByRole('button',{name:'Add note',exact:true}).click();await page.getByRole('button',{name:'Switch anyway',exact:true}).click();await expect(editor).toHaveText('');await insertNoteReference(page,'Gen 1');await expect(editor.locator('[data-note-passage]')).toHaveCount(1);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note))).toHaveLength(0);
  519 | });
  520 | test('note links review: source link refuses selection containing owned atom before mutation',async({page})=>{
  521 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Explanation ');await insertNoteReference(page,'Gen 1');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const before=await editor.innerHTML(),writes=requests.filter(r=>r.method==='PUT').length;await editor.press('ControlOrMeta+a');await page.getByRole('button',{name:'Link',exact:true}).click();await page.getByLabel('Link URL',{exact:true}).fill('https://example.org/source');await page.getByRole('button',{name:'Insert link',exact:true}).click();await expect(page.getByRole('alert')).toContainText('Select ordinary text');await expect(page.getByLabel('Link URL',{exact:true})).toHaveValue('https://example.org/source');expect(await editor.innerHTML()).toBe(before);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(writes);
  522 | });
  523 | test('note links review: inline boundary refuses insertion without changing writing or closing candidate',async({page})=>{
  524 |  await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.evaluate(el=>{const p=document.createElement('p');for(let i=0;i<256;i++){const span=document.createElement('span');span.textContent='x';p.append(span);}el.replaceChildren(p);el.dispatchEvent(new InputEvent('input',{bubbles:true}));getSelection().removeAllRanges();});await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const before=await editor.innerHTML();await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();const input=page.getByLabel('Passage reference',{exact:true});await input.fill('Gen 1');await input.press('Enter');await expect(input).toHaveValue('Gen 1');const feedbackId=await input.getAttribute('aria-describedby');expect(feedbackId).toBeTruthy();await expect(page.locator('[id="'+feedbackId+'"]')).toHaveAttribute('aria-live','polite');expect(await editor.innerHTML()).toBe(before);await expect(editor.locator('[data-note-passage]')).toHaveCount(0);await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();
  525 | });
  526 | test('note links review: retained reference reopens at its candidate book and rejection is accessible',async({page})=>{
  527 |  await setup(page);await firstNote(page);await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();const input=page.getByLabel('Passage reference',{exact:true});await input.fill('Ps 110:1');await page.getByRole('button',{name:'Cancel',exact:true}).click();await page.getByRole('button',{name:'Insert passage reference',exact:true}).click();await expect(input).toHaveValue('Ps 110:1');await expect(page.getByRole('group',{name:'Chapters of Psalms',exact:true})).toBeVisible();await input.fill('Ps 2:13');await expect(input).toHaveAttribute('aria-invalid','true');const errorId=await input.getAttribute('aria-describedby');expect(errorId).toBeTruthy();await expect(page.locator('[id="'+errorId+'"]')).toHaveAttribute('role','alert');await expect(page.locator('[id="'+errorId+'"]')).toContainText('Enter a valid');
  528 | });
  529 | for(const command of ['Bold','Italic','Bullet list','Numbered list'])test(`note links review: ${command} across an owned atom survives save reload`,async({page})=>{
> 530 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Before ');await insertNoteReference(page,'Gen 1');await editor.press('End');await editor.pressSequentially(' after');await editor.press('ControlOrMeta+a');await page.getByRole('button',{name:command,exact:true}).click();await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const saved=requests.filter(r=>r.method==='PUT').at(-1).payload.value;expect(JSON.stringify(saved)).toContain('passage_link');await page.reload();await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'Untitled study',exact:true}).click();await page.getByRole('list',{name:'Notes',exact:true}).getByRole('button').click();await expect(editor).toHaveText('Before Genesis 1 after');await expect(editor.locator('[data-note-passage]')).toHaveCount(1);if(command==='Bold'||command==='Italic'){const paragraphs=saved.document.blocks.flatMap(b=>b.type==='paragraph'?[b]:b.items.flat());expect(paragraphs.flatMap(p=>p.content).filter(i=>i.type==='text').every(i=>i.marks.includes(command.toLowerCase()))).toBe(true);}else expect(saved.document.blocks[0].type).toBe('list');
      |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ^ Error: locator.click: Test timeout of 30000ms exceeded.
  531 | });
  532 | test('note links review: passage-only saved Notes preview reopens with plain reference label',async({page})=>{
  533 |  await setup(page);await firstNote(page);await insertNoteReference(page,'Gen 1');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();await page.getByRole('button',{name:'Back to Studies',exact:true}).click();const button=page.getByRole('list',{name:'Notes',exact:true}).getByRole('button');await expect(button).toHaveText('Genesis 1');await button.click();await expect(page.getByLabel('Note text',{exact:true}).locator('[data-note-passage]')).toHaveText('Genesis 1');
  534 | });
  535 | test('note links review: noncanonical stored Unicode HTML-looking label stays plain and exact',async({page})=>{
  536 |  const catalogue=require('../src/generated/reference-catalogue.json'),label='שָׁלוֹם 😀 <b>stored</b> e\u0301',reference={catalogue_id:catalogue.catalogue_id,catalogue_version:catalogue.catalogue_version,versification_id:catalogue.books.find(b=>b.book_id==='Gen').versification_id,book_id:'Gen',target:{kind:'chapter',chapter:1}},noteValue={document:{version:2,blocks:[{type:'paragraph',direction:'rtl',content:[{type:'passage_link',reference,label}]}]},connections:[],highlights:[]};const {requests}=await setup(page,{noteValue});await firstNote(page);const editor=page.getByLabel('Note text',{exact:true}),atom=editor.locator('[data-note-passage]');await expect(atom).toHaveText(label);await expect(atom.locator('b')).toHaveCount(0);await page.getByRole('button',{name:'Read note',exact:true}).click();await expect(atom).toHaveText(label);await page.getByRole('button',{name:'Edit note',exact:true}).click();await editor.press('End');await editor.press('!');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const saved=requests.filter(r=>r.method==='PUT').at(-1).payload.value;expect(saved.document.blocks[0].content.find(i=>i.type==='passage_link')).toEqual({type:'passage_link',reference,label});
  537 | });
  538 | test('note links review: ordinary copied metadata never acquires native-history ownership',async({page})=>{
  539 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await insertNoteReference(page,'Gen 1');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();const before=requests.filter(r=>r.method==='PUT').length;await editor.locator('[data-note-passage]').evaluate(el=>{el.replaceWith(el.cloneNode(true));document.querySelector('[aria-label="Note text"]').dispatchEvent(new InputEvent('input',{bubbles:true}));});await expect(page.getByRole('status')).toContainText('Changes not saved');await expect(page.getByRole('button',{name:'Read note',exact:true})).toBeDisabled();await page.waitForTimeout(600);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(before);
  540 | });
  541 | for(const method of ['paste','keyless input'])test(`note links review: ${method} at final atom uses editable caret boundary`,async({page})=>{
  542 |  await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await insertNoteReference(page,'Gen 1');await editor.press('ControlOrMeta+z');await editor.press('ControlOrMeta+Shift+z');await editor.press('End');if(method==='paste')await editor.evaluate(el=>{const data=new DataTransfer();data.setData('text/plain',' pasted');el.dispatchEvent(new ClipboardEvent('paste',{bubbles:true,clipboardData:data}));});else await page.keyboard.insertText(' keyless');await expect(editor).toHaveText('Genesis 1'+(method==='paste'?' pasted':' keyless'));await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();
  543 | });
  544 | 
  545 | for(const prefix of ['', 'Keep'])for(const action of ['Backspace','Delete','beforeinput backward'])test(`note links deletion: ${action} on ${prefix||'empty'} removes one owned atom and native Undo Redo retains version2`,async({page})=>{
  546 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});if(prefix)await editor.pressSequentially(prefix);await insertNoteReference(page,'Gen 1');await editor.locator('[data-note-passage]').evaluate((atom,action)=>{const editor=document.querySelector('[aria-label="Note text"]'),range=document.createRange();if(action==='Delete')range.setStartBefore(atom);else range.setStartAfter(atom);range.collapse(true);editor.focus();getSelection().removeAllRanges();getSelection().addRange(range);if(action==='beforeinput backward'){editor.dataset.backwardInputs='0';editor.addEventListener('keydown',event=>event.stopImmediatePropagation(),{capture:true,once:true});editor.addEventListener('beforeinput',event=>{if(event.inputType==='deleteContentBackward')editor.dataset.backwardInputs=String(Number(editor.dataset.backwardInputs)+1);});}},action);await editor.press(action==='Delete'?'Delete':'Backspace');await expect(editor.locator('[data-note-passage]')).toHaveCount(0);await expect(editor).toHaveText(prefix);if(action==='beforeinput backward')await expect(editor).toHaveAttribute('data-backward-inputs','1');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.version).toBe(2);
  547 |  await editor.press('ControlOrMeta+z');await expect(editor.locator('[data-note-passage]')).toHaveText('Genesis 1');await expect(editor).toHaveText(prefix+'Genesis 1');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.version).toBe(2);await editor.press('ControlOrMeta+Shift+z');await expect(editor.locator('[data-note-passage]')).toHaveCount(0);await expect(editor).toHaveText(prefix);await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT').at(-1).payload.value.document.version).toBe(2);
  548 | });
  549 | 
  550 | test('library search finds saved results beyond the first page and returns at loaded depth',async({page})=>{
  551 |  await setup(page);
  552 |  const reads=[];
  553 |  await page.route('**/api/studies/search',async r=>{
  554 |   const body=r.request().postDataJSON();reads.push(body);
  555 |   const items=body.query==='שלום'?[{...attribution,id:study,title:'Saved Hebrew study',revision:'1'}]:[{...attribution,id:study,title:'Untitled study',revision:'1'}];
  556 |   await r.fulfill({json:{items,next_cursor:body.cursor?null:'search-page-two'}});
  557 |  });
  558 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();
  559 |  await page.getByRole('textbox',{name:'Search studies',exact:true}).fill('שלום');
  560 |  await page.getByRole('button',{name:'Search',exact:true}).click();
  561 |  await expect(page.getByRole('button',{name:'Saved Hebrew study',exact:true})).toBeVisible();
  562 |  await page.getByRole('button',{name:'More studies',exact:true}).click();
  563 |  await expect(page.getByRole('button',{name:'More studies',exact:true})).toHaveCount(0);
  564 |  await expect(page.getByRole('button',{name:'Saved Hebrew study',exact:true})).toHaveCount(1);
  565 |  await page.getByRole('button',{name:'Saved Hebrew study',exact:true}).click();
  566 |  await page.getByRole('button',{name:'Leave study',exact:true}).click();
  567 |  await expect(page.getByRole('textbox',{name:'Search studies',exact:true})).toHaveValue('שלום');
  568 |  await expect.poll(()=>reads.filter(x=>x.query==='שלום').length).toBe(4);
  569 |  expect(reads.filter(x=>x.query==='שלום').map(x=>x.cursor??null)).toEqual([null,'search-page-two',null,'search-page-two']);
  570 |  expect(new URL(page.url()).search).not.toContain('שלום');
  571 |  expect(await page.evaluate(()=>JSON.stringify(localStorage)+JSON.stringify(sessionStorage))).not.toContain('שלום');
  572 | });
  573 | 
  574 | test('library search candidate Enter Clear and literal Unicode terms stay in read bodies',async({page})=>{
  575 |  const reads=[];await setup(page,{search:async(r,body)=>{reads.push(body);return r.fulfill({json:{items:[{...attribution,id:study,title:body.query||'Whole library',revision:'1'}],next_cursor:null}});}});
  576 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();
  577 |  const input=page.getByRole('textbox',{name:'Search studies',exact:true});
  578 |  await expect(page.getByRole('button',{name:'Whole library',exact:true})).toBeVisible();
  579 |  for(const query of ['Genesis 1:31–2:3','בראשית א:לא–ב:ג','Matthew','café 100% _ \\ "']){
  580 |   const count=reads.length;await input.fill(query);expect(reads.length).toBe(count);await input.press('Enter');await expect(page.getByRole('list',{name:'Studies',exact:true})).toContainText(query);
  581 |  }
  582 |  await page.getByRole('button',{name:'Clear',exact:true}).click();await expect(input).toHaveValue('');await expect(page.getByRole('button',{name:'Whole library',exact:true})).toBeVisible();
  583 |  expect(reads.every(body=>Object.keys(body).sort().join(',')==='cursor,query')).toBe(true);
  584 |  expect(await page.evaluate(()=>JSON.stringify(localStorage)+JSON.stringify(sessionStorage))).not.toContain('café');
  585 |  expect(new URL(page.url()).search).not.toContain('query');
  586 | });
  587 | 
  588 | for(const late of ['success','denial'])test(`library search ignores late old-query ${late} and loading finalizers`,async({page})=>{
  589 |  let release;await setup(page,{search:async(r,body)=>{
  590 |   if(body.query==='old'){await new Promise(resolve=>release=resolve);return r.fulfill(late==='denial'?{status:403,json:{code:'studies_access_denied'}}:{json:{items:[{...attribution,id:study,title:'Old private title',revision:'1'}],next_cursor:null}});}
  591 |   return r.fulfill({json:{items:body.query?[{...attribution,id:study,title:'Current title',revision:'1'}]:[],next_cursor:null}});
  592 |  }});
  593 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();const input=page.getByRole('textbox',{name:'Search studies',exact:true});
  594 |  await input.fill('old');await input.press('Enter');await expect.poll(()=>!!release).toBe(true);
  595 |  await input.fill('current');await input.press('Enter');await expect(page.getByRole('button',{name:'Current title',exact:true})).toBeVisible();release();
  596 |  await page.waitForTimeout(100);await expect(page.getByRole('button',{name:'Current title',exact:true})).toBeVisible();await expect(page.getByText('Old private title',{exact:true})).toHaveCount(0);await expect(page.getByText('Studies access is unavailable for this account.',{exact:false})).toHaveCount(0);
  597 | });
  598 | 
  599 | test('library search hides unavailable pages retries applied input and clears on denial',async({page})=>{
  600 |  let failure=0;const reads=[];await setup(page,{search:async(r,body)=>{reads.push(body.query);return r.fulfill(failure?{status:failure,json:{code:failure===403?'studies_access_denied':'studies_access_unavailable'}}:{json:{items:[{...attribution,id:study,title:'Verified title',revision:'1'}],next_cursor:'next'}});}});
  601 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();const input=page.getByRole('textbox',{name:'Search studies',exact:true});await input.fill('applied');await input.press('Enter');await expect(page.getByRole('button',{name:'Verified title',exact:true})).toBeVisible();
  602 |  failure=503;await page.getByRole('button',{name:'More studies',exact:true}).click();await expect(page.getByRole('button',{name:'Verified title',exact:true})).toHaveCount(0);await expect(input).toHaveValue('applied');
  603 |  await input.fill('candidate only');failure=0;await page.getByRole('button',{name:'Retry search',exact:true}).click();await expect(page.getByRole('button',{name:'Verified title',exact:true})).toBeVisible();expect(reads.at(-1)).toBe('applied');await expect(input).toHaveValue('candidate only');
  604 |  failure=403;await page.getByRole('button',{name:'More studies',exact:true}).click();await expect(input).toHaveValue('');await expect(page.getByRole('button',{name:'Verified title',exact:true})).toHaveCount(0);
  605 | });
  606 | 
  607 | test('library search deduplicates More and rejects a late page after query change',async({page})=>{
  608 |  let release;const reads=[];await setup(page,{search:async(r,body)=>{reads.push(body);if(body.cursor){await new Promise(resolve=>release=resolve);return r.fulfill({json:{items:[{...attribution,id:study,title:'Late page',revision:'1'}],next_cursor:null}});}return r.fulfill({json:{items:[{...attribution,id:study,title:body.query||'First page',revision:'1'}],next_cursor:'next'}});}});
  609 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'More studies',exact:true}).dblclick();await expect.poll(()=>!!release).toBe(true);expect(reads.filter(x=>x.cursor).length).toBe(1);
  610 |  await page.getByRole('textbox',{name:'Search studies',exact:true}).fill('New query');await page.getByRole('button',{name:'Search',exact:true}).click();await expect(page.getByRole('button',{name:'New query',exact:true})).toBeVisible();release();await page.waitForTimeout(100);await expect(page.getByRole('button',{name:'Late page',exact:true})).toHaveCount(0);
  611 | });
  612 | 
  613 | test('library search restores multi-page scroll and stable result focus after refreshed return',async({page})=>{
  614 |  let reads=0;await setup(page,{search:async(r,body)=>{reads++;const offset=body.cursor?20:0;const items=Array.from({length:20},(_,index)=>{const n=offset+index;return {...attribution,id:n===35?study:`30000000-0000-4000-8000-${String(n+10).padStart(12,'0')}`,title:`Result ${n}`,revision:'1'};});return r.fulfill({json:{items,next_cursor:body.cursor?null:'second'}});}});
  615 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'More studies',exact:true}).click();const result=page.getByRole('button',{name:'Result 35',exact:true});await result.scrollIntoViewIfNeeded();await result.focus();const before=await page.getByRole('complementary',{name:'Study tools',exact:true}).evaluate(el=>el.scrollTop);expect(before).toBeGreaterThan(0);await result.click();await page.getByRole('button',{name:'Leave study',exact:true}).click();
  616 |  await expect.poll(()=>reads).toBe(4);await expect(result).toBeFocused();await expect.poll(()=>page.getByRole('complementary',{name:'Study tools',exact:true}).evaluate(el=>el.scrollTop)).toBeGreaterThan(before-50);
  617 | });
  618 | 
  619 | test('library search account replacement clears candidates pages and rejects late denial',async({page})=>{
  620 |  let release;await setup(page,{search:async(r,body)=>{if(body.query){await new Promise(resolve=>release=resolve);return r.fulfill({status:403,json:{code:'studies_access_denied'}});}return r.fulfill({json:{items:[],next_cursor:null}});}});
  621 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('textbox',{name:'Search studies',exact:true}).fill('old private writing');await page.getByRole('button',{name:'Search',exact:true}).click();await expect.poll(()=>!!release).toBe(true);
  622 |  await page.route('**/auth/v1/token*',r=>r.fulfill({json:{...session,access_token:'other-account',user:{...session.user,id:'10000000-0000-4000-8000-000000000002'}}}));await page.evaluate(async()=>{const {supabase}=await import('/src/lib/supabase.ts');await supabase.auth.signInWithPassword({email:'other@example.invalid',password:'fixture'});});
  623 |  await expect(page.getByRole('button',{name:'Studies',exact:true})).toHaveAttribute('aria-pressed','false');await expect(page.getByRole('button',{name:'Analysis',exact:true})).toHaveAttribute('aria-pressed','false');await expect(page.getByRole('textbox',{name:'Search studies',exact:true})).toHaveCount(0);await page.getByRole('button',{name:'Studies',exact:true}).click();await expect(page.getByRole('textbox',{name:'Search studies',exact:true})).toHaveValue('');await page.getByRole('button',{name:'Search',exact:true}).click();await expect(page.getByText('No saved studies found.',{exact:true})).toBeVisible();release();await page.waitForTimeout(100);await expect(page.getByText('Studies access is unavailable for this account.',{exact:false})).toHaveCount(0);
  624 | });
  625 | 
  626 | test('library search old completion cannot stop current loading',async({page})=>{
  627 |  const releases={};await setup(page,{search:async(r,body)=>{if(body.query)await new Promise(resolve=>releases[body.query]=resolve);return r.fulfill({json:{items:[],next_cursor:null}});}});
  628 |  await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();const input=page.getByRole('textbox',{name:'Search studies',exact:true});await input.fill('old');await input.press('Enter');await expect.poll(()=>!!releases.old).toBe(true);await input.fill('new');await input.press('Enter');await expect.poll(()=>!!releases.new).toBe(true);releases.old();await page.waitForTimeout(100);await expect(page.getByRole('status').filter({hasText:'Loading studies…'})).toBeVisible();releases.new();await expect(page.getByRole('status').filter({hasText:'Loading studies…'})).toHaveCount(0);
  629 | });
  630 | 
```