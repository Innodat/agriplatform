# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personal-notes.spec.cjs >> note deletion composing cancel preserves final composition through saving and reopen
- Location: tests/personal-notes.spec.cjs:786:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Untitled study', exact: true })
    - locator resolved to <button class="underline py-2" data-study-id="30000000-0000-4000-8000-000000000001">Untitled study</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
  - element was detached from the DOM, retrying

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - banner [ref=f1e5]:
    - generic [ref=f1e6]:
      - generic [ref=f1e7]: Scribes' Well
      - generic [ref=f1e13]:
        - generic [ref=f1e14]: reader@example.invalid
        - button "Sign out" [ref=f1e18]
  - main [ref=f1e22]:
    - generic [ref=f1e23]:
      - generic [ref=f1e24]:
        - tablist "Workspace tabs" [ref=f1e25]:
          - generic [ref=f1e26]:
            - tab "Genesis 1" [selected] [ref=f1e27]
            - button "Rename tab 1" [ref=f1e28]: Rename
        - button "New workspace tab" [ref=f1e29]: + New tab
      - generic [ref=f1e30]:
        - button "Add reader pane" [ref=f1e31]
        - button "Enter focus mode" [ref=f1e34]: Focus mode
      - navigation "Reader tools" [ref=f1e40]:
        - button "Studies" [active] [pressed] [ref=f1e41]
        - button "Analysis" [ref=f1e42]
        - generic [ref=f1e43]: Untitled study
      - generic [ref=f1e44]:
        - tabpanel "Genesis 1" [ref=f1e45]:
          - region "Passage 1" [ref=f1e46]:
            - generic [ref=f1e47]:
              - button "Previous chapter" [disabled] [ref=f1e48]
              - 'button "Navigate: Genesis, chapter 1. Open selector." [ref=f1e52]': Genesis א
              - button "Next chapter" [disabled] [ref=f1e55]
            - region "Chapter text" [ref=f1e58]:
              - list "Verses" [ref=f1e59]:
                - listitem [ref=f1e60]:
                  - generic "Verse 1" [ref=f1e61]: "1"
                  - paragraph [ref=f1e62]:
                    - 'button "Word: בְּרֵאשִׁית" [ref=f1e63] [cursor=pointer]': בְּרֵאשִׁית
        - complementary "Study tools" [ref=f1e64]:
          - region "My studies" [ref=f1e66]:
            - heading "My studies" [level=2] [ref=f1e67]
            - heading "Untitled study" [level=3] [ref=f1e68]
            - button "Delete study" [ref=f1e69]
            - button "Rename" [ref=f1e70]
            - button "Add note" [ref=f1e71]
            - list "Notes" [ref=f1e72]:
              - listitem [ref=f1e73]:
                - button "final composed שָׁלוֹם" [ref=f1e74]
            - region "Collected passages" [ref=f1e75]:
              - heading "Passages" [level=4] [ref=f1e76]
              - button "Add passage" [disabled] [ref=f1e78]
              - button "Add current passage" [disabled] [ref=f1e82]
              - list "Passages"
            - button "Leave study" [ref=f1e85]
```

# Test source

```ts
  691 | 
  692 | test('note deletion requires safe-focused confirmation and cancel preserves dirty writing',async({page})=>{
  693 |  const {requests}=await setup(page);await firstNote(page);
  694 |  await page.getByLabel('Note text',{exact:true}).fill('private unsent writing');
  695 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();
  696 |  const dialog=page.getByRole('dialog',{name:'Delete this note?'});
  697 |  await expect(dialog).toBeVisible();await expect(dialog).toContainText('permanently');await expect(dialog).toContainText('cannot be undone');await expect(dialog.getByRole('button',{name:'Cancel',exact:true})).toBeFocused();
  698 |  await dialog.getByRole('button',{name:'Cancel',exact:true}).click();
  699 |  await expect(page.getByLabel('Note text',{exact:true})).toContainText('private unsent writing');
  700 |  expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);
  701 | });
  702 | 
  703 | 
  704 | test('confirmed dirty note deletion erases just the target without saving unsent writing',async({page})=>{
  705 |  const {requests}=await setup(page);await firstNote(page);
  706 |  await page.getByLabel('Note text',{exact:true}).fill('do not save merely to erase');
  707 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();
  708 |  await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();
  709 |  await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.getByLabel('Note text',{exact:true})).toHaveCount(0);await expect(page.getByText('Select a note in Studies.',{exact:true})).toBeFocused();
  710 |  expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(1);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note))).toHaveLength(0);
  711 |  await page.getByRole('button',{name:'Studies',exact:true}).click();await expect(page.getByRole('heading',{name:'Untitled study',exact:true})).toBeVisible();await expect(page.getByRole('list',{name:'Notes',exact:true}).getByRole('button')).toHaveCount(0);
  712 | });
  713 | 
  714 | test('unknown delete retains frozen writing and explicitly retries the original operation',async({page})=>{
  715 |  const options={dropDelete:true,unresolved:true};const {requests}=await setup(page,options);await firstNote(page);
  716 |  await page.getByLabel('Note text',{exact:true}).fill('retained until acknowledgement');await page.getByRole('button',{name:'Delete note',exact:true}).click();
  717 |  await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();
  718 |  await expect(page.getByRole('dialog')).toContainText('Deletion not confirmed');await expect(page.getByLabel('Note text',{exact:true})).toContainText('retained until acknowledgement');
  719 |  await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();
  720 |  await expect(page.getByLabel('Note text',{exact:true})).toHaveAttribute('contenteditable','false');
  721 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('button',{name:'Retry deletion',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  722 |  const deletes=requests.filter(r=>r.method==='DELETE');expect(deletes).toHaveLength(2);expect(deletes[1].payload).toEqual(deletes[0].payload);
  723 | });
  724 | 
  725 | test('deletion waits for executing save and uses its confirmed revision',async({page})=>{
  726 |  let release;const options={beforePut:()=>new Promise(resolve=>{release=resolve;})};const {requests}=await setup(page,options);await firstNote(page);
  727 |  await page.getByLabel('Note text',{exact:true}).fill('executing save');await expect.poll(()=>!!release).toBe(true);
  728 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true})).toBeDisabled();expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);
  729 |  release();await expect(page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true})).toBeEnabled();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  730 |  expect(requests.find(r=>r.method==='DELETE').payload.expected_revision).toBe('2');
  731 | });
  732 | 
  733 | test('delete conflict preserves writing and requires review and a fresh explicit confirmation',async({page})=>{
  734 |  const options={failDelete:409};const {requests,advanceNote}=await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('local work');
  735 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Deletion not confirmed');await expect(page.getByLabel('Note text',{exact:true})).toContainText('local work');
  736 |  options.failDelete=0;advanceNote({document:{version:1,blocks:[]},connections:[],highlights:[]});await page.getByRole('button',{name:'Review current note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Current note loaded');expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(1);
  737 |  await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  738 |  const deletes=requests.filter(r=>r.method==='DELETE');expect(deletes[0].payload.operation_id).not.toBe(deletes[1].payload.operation_id);expect(deletes[1].payload.expected_revision).toBe('2');await expect(page.getByLabel('Note text',{exact:true})).toHaveCount(0);
  739 | });
  740 | 
  741 | test('unknown previous save must recover before separately confirmed deletion',async({page})=>{
  742 |  const options={dropPut:true,unresolved:true};const {requests}=await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('unknown previous save');await expect(page.getByRole('button',{name:'Retry',exact:true})).toBeVisible();
  743 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Recover that save first');expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);
  744 |  options.unresolved=false;await page.getByRole('button',{name:'Recover previous save',exact:true}).click();await expect(page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true})).toBeEnabled();expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);
  745 |  await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  746 |  const saves=requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note));expect(saves).toHaveLength(2);expect(saves[0].payload).toEqual(saves[1].payload);
  747 | });
  748 | 
  749 | for(const late of ['success','denial'])test('note deletion account replacement rejects late '+late,async({page})=>{
  750 |  let release;const options={beforeDelete:()=>new Promise(resolve=>release=resolve),failDelete:late==='denial'?403:0};const {requests}=await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('old account private writing');
  751 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect.poll(()=>!!release).toBe(true);
  752 |  await page.route('**/auth/v1/token*',r=>r.fulfill({json:{...session,access_token:'other-account',user:{...session.user,id:'10000000-0000-4000-8000-000000000002'}}}));
  753 |  await page.evaluate(async()=>{const {supabase}=await import('/src/lib/supabase.ts');await supabase.auth.signInWithPassword({email:'other@example.invalid',password:'fixture'});});
  754 |  await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.getByLabel('Note text',{exact:true})).toHaveCount(0);const currentControl=page.getByRole('button',{name:'Studies',exact:true});await currentControl.focus();const lateReply=page.waitForResponse(r=>r.request().method()==='DELETE');release();await (await lateReply).finished();await page.evaluate(()=>new Promise(requestAnimationFrame));await expect(currentControl).toBeFocused();await expect(page.getByText('old account private writing')).toHaveCount(0);await expect(page.getByText('Studies access is unavailable for this account.')).toHaveCount(0);expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(1);
  755 | });
  756 | 
  757 | test('note deletion navigation preserves an unknown operation and suppresses fresh saves',async({page})=>{
  758 |  const options={dropDelete:true,unresolved:true};const {requests}=await setup(page,options);await firstNote(page);
  759 |  await page.getByLabel('Note text',{exact:true}).fill('original private unsent writing');await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Deletion not confirmed');await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();
  760 |  await page.getByRole('button',{name:'Back to Studies',exact:true}).click();await page.getByRole('button',{name:'Leave study',exact:true}).click();await page.getByRole('button',{name:'Untitled study',exact:true}).click();
  761 |  // The fixture has committed the tombstone and omits it from lists; the retained
  762 |  // target is still recoverable by returning to the current Analysis lane.
  763 |  await page.getByRole('button',{name:'Analysis',exact:true}).click();
  764 |  // Navigation clears selection, so reopen recovery through an explicit retained action.
  765 |  await expect(page.getByRole('button',{name:/^Recover deletion:/})).toBeVisible();await page.getByRole('button',{name:/^Recover deletion:/}).click();
  766 |  await page.getByRole('button',{name:'Retry deletion',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  767 |  const deletes=requests.filter(r=>r.method==='DELETE');expect(deletes).toHaveLength(2);expect(deletes[0].payload).toEqual(deletes[1].payload);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note))).toHaveLength(0);
  768 | });
  769 | 
  770 | test('note deletion captured target does not evict a different selected note after navigation',async({page})=>{
  771 |  let release;const {requests}=await setup(page,{beforeDelete:()=>new Promise(resolve=>release=resolve)});await firstNote(page);
  772 |  const other='40000000-0000-4000-8000-000000000002',otherValue={document:{version:1,blocks:[{type:'paragraph',direction:'auto',content:[{type:'text',text:'Other note survives',marks:[]}]}]},connections:[],highlights:[]};
  773 |  await page.route('**/api/studies/'+study+'/notes',r=>r.request().method()==='GET'?r.fulfill({json:{items:[{...attribution,id:other,study_id:study,visibility:'study',revision:'1',value:otherValue}],next_cursor:null}}):r.fallback());
  774 |  await page.route('**/api/studies/'+study+'/notes/'+other,r=>r.fulfill({json:{...attribution,id:other,study_id:study,visibility:'study',revision:'1',value:otherValue}}));
  775 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect.poll(()=>!!release).toBe(true);await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();
  776 |  await page.getByRole('button',{name:'Back to Studies',exact:true}).click();await page.getByRole('button',{name:'Leave study',exact:true}).click();await page.getByRole('button',{name:'Untitled study',exact:true}).click();await page.getByRole('button',{name:'Other note survives',exact:true}).click();
  777 |  await page.getByLabel('Note text',{exact:true}).focus();const lateReply=page.waitForResponse(r=>r.request().method()==='DELETE');release();await (await lateReply).finished();await page.evaluate(()=>new Promise(requestAnimationFrame));await expect(page.getByLabel('Note text',{exact:true})).toContainText('Other note survives');await expect(page.getByLabel('Note text',{exact:true})).toBeFocused();expect(requests.find(r=>r.method==='DELETE').path).toBe('/api/studies/'+study+'/notes/'+note);
  778 | });
  779 | 
  780 | test('note deletion after a definitive prior-save conflict reviews current revision and clears only failed save identity',async({page})=>{
  781 |  const options={failPut:409};const {requests,advanceNote}=await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('my conflicting save');await expect(page.getByRole('alert')).toContainText('This note has changed');
  782 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Review the current note');advanceNote({document:{version:1,blocks:[]},connections:[],highlights:[]});await page.getByRole('button',{name:'Review current note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Current note loaded');await expect(page.getByLabel('Note text',{exact:true})).toContainText('my conflicting save');
  783 |  await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(1);expect(requests.find(r=>r.method==='DELETE').payload.expected_revision).toBe('2');await expect(page.getByLabel('Note text',{exact:true})).toHaveCount(0);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note))).toHaveLength(1);
  784 | });
  785 | 
  786 | test('note deletion composing cancel preserves final composition through saving and reopen',async({page})=>{
  787 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.dispatchEvent('compositionstart');await editor.fill('initial composing text');await page.getByRole('button',{name:'Delete note',exact:true}).click();
  788 |  await editor.evaluate(el=>{el.textContent='final composed שָׁלוֹם';el.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true}));});
  789 |  await page.getByRole('dialog').getByRole('button',{name:'Cancel',exact:true}).click();await expect(editor).toContainText('final composed שָׁלוֹם');await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();
  790 |  expect(JSON.stringify(requests.filter(r=>r.method==='PUT').at(-1).payload.value)).toContain('final composed שָׁלוֹם');
> 791 |  await page.reload();await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'Untitled study',exact:true}).click();await page.getByRole('button',{name:'final composed שָׁלוֹם',exact:true}).click();await expect(editor).toContainText('final composed שָׁלוֹם');expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);
      |                                                                                                                                                           ^ Error: locator.click: Test timeout of 30000ms exceeded.
  792 | });
  793 | 
  794 | test('note deletion bounded preparation keeps unresolved save and requires original recovery',async({page})=>{
  795 |  let release;const {requests}=await setup(page,{beforePut:()=>new Promise(resolve=>release=resolve)});await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('still saving');await expect.poll(()=>!!release).toBe(true);
  796 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('button',{name:'Recover previous save',exact:true})).toBeVisible({timeout:6500});expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);
  797 |  release();await page.getByRole('button',{name:'Recover previous save',exact:true}).click();await expect(page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true})).toBeEnabled();expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note))).toHaveLength(1);
  798 |  await page.getByRole('dialog').getByRole('button',{name:'Cancel',exact:true}).click();await expect(page.getByLabel('Note text',{exact:true})).toContainText('still saving');
  799 | });
  800 | 
  801 | test('note deletion filters a stale notes page arriving after committed acknowledgement',async({page})=>{
  802 |  let releaseDelete,releasePage;await setup(page,{beforeDelete:()=>new Promise(resolve=>releaseDelete=resolve)});await firstNote(page);
  803 |  await page.route('**/api/studies/'+study+'/notes',async r=>{if(r.request().method()!=='GET')return r.fallback();const stale={items:[{...attribution,id:note,study_id:study,visibility:'study',revision:'1',value:{document:{version:1,blocks:[]},connections:[],highlights:[]}}],next_cursor:null};await new Promise(resolve=>releasePage=resolve);return r.fulfill({json:stale});});
  804 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect.poll(()=>!!releaseDelete).toBe(true);await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();
  805 |  await page.getByRole('button',{name:'Back to Studies',exact:true}).click();await page.getByRole('button',{name:'Leave study',exact:true}).click();await page.getByRole('button',{name:'Untitled study',exact:true}).click();await expect.poll(()=>!!releasePage).toBe(true);
  806 |  const committed=page.waitForResponse(r=>r.request().method()==='DELETE');releaseDelete();await committed;releasePage();await expect(page.getByRole('heading',{name:'Untitled study',exact:true})).toBeVisible();await expect(page.getByRole('list',{name:'Notes',exact:true})).toBeAttached();await expect(page.getByRole('list',{name:'Notes',exact:true}).getByRole('button')).toHaveCount(0);
  807 | });
  808 | 
  809 | test('note deletion lost reply resolves through read-only original outcome lookup',async({page})=>{
  810 |  const {requests}=await setup(page,{dropDelete:true});await firstNote(page);await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.getByLabel('Note text',{exact:true})).toHaveCount(0);expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(1);
  811 | });
  812 | 
  813 | test('note deletion same-account authority recovery never automatically repeats deletion',async({page})=>{
  814 |  const options={failDelete:401};const {requests}=await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('recoverable private input');await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.getByLabel('Note text',{exact:true})).toHaveCount(0);
  815 |  options.failDelete=0;await page.getByRole('button',{name:'Retry Studies',exact:true}).click();await expect(page.getByRole('button',{name:/^Recover deletion:/})).toBeVisible();expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(1);
  816 |  await page.getByRole('button',{name:/^Recover deletion:/}).click();await page.getByRole('button',{name:'Retry deletion',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);const deletes=requests.filter(r=>r.method==='DELETE');expect(deletes).toHaveLength(2);expect(deletes[0].payload).toEqual(deletes[1].payload);
  817 | });
  818 | 
  819 | for(const origin of ['save','delete'])test('note deletion review Cancel does not authorize stale autosave after '+origin+' conflict',async({page})=>{
  820 |  const options=origin==='save'?{failPut:409}:{failDelete:409};const {requests}=await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('my retained stale writing');if(origin==='save')await expect(page.getByRole('alert')).toContainText('This note has changed');
  821 |  await page.getByRole('button',{name:'Delete note',exact:true}).click();if(origin==='delete')await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();
  822 |  const remote={document:{version:1,blocks:[{type:'paragraph',direction:'auto',content:[{type:'text',text:'Concurrent saved writing',marks:[]}]}]},connections:[],highlights:[]};
  823 |  await page.route('**/api/studies/'+study+'/notes/'+note,r=>r.request().method()==='GET'?r.fulfill({json:{...attribution,id:note,study_id:study,visibility:'study',revision:'2',value:remote}}):r.fallback());
  824 |  await page.getByRole('button',{name:'Review current note',exact:true}).click();await expect(page.getByRole('region',{name:'Current saved note',exact:true})).toContainText('Concurrent saved writing');const prior=requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note)).length;
  825 |  await page.getByRole('dialog').getByRole('button',{name:'Cancel',exact:true}).click();await expect(page.getByLabel('Note text',{exact:true})).toContainText('my retained stale writing');await page.waitForTimeout(800);expect(requests.filter(r=>r.method==='PUT'&&r.path.endsWith('/notes/'+note))).toHaveLength(prior);
  826 | });
  827 | 
  828 | test('deletion review excludes overlapping same-target requests and keeps one confirmed revision',async({page})=>{
  829 |  const options={failDelete:409};const {requests,advanceNote}=await setup(page,options);await firstNote(page);await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();
  830 |  let release,reads=0;const remote={document:{version:1,blocks:[{type:'paragraph',direction:'auto',content:[{type:'text',text:'Reviewed saved writing',marks:[]}]}]},connections:[],highlights:[]};advanceNote(remote);
  831 |  await page.route('**/api/studies/'+study+'/notes/'+note,async r=>{if(r.request().method()!=='GET')return r.fallback();reads++;if(reads===1)await new Promise(resolve=>release=resolve);return r.fulfill({json:{...attribution,id:note,study_id:study,visibility:'study',revision:reads===1?'2':'3',value:remote}});});
  832 |  await page.getByRole('button',{name:'Review current note',exact:true}).evaluate(button=>{button.click();button.click();});await expect.poll(()=>!!release).toBe(true);await page.waitForTimeout(100);expect(reads).toBe(1);await expect(page.getByRole('button',{name:'Review current note',exact:true})).toBeDisabled();
  833 |  release();await expect(page.getByRole('region',{name:'Current saved note',exact:true})).toContainText('Reviewed saved writing');options.failDelete=0;await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);expect(requests.filter(r=>r.method==='DELETE').at(-1).payload.expected_revision).toBe('2');
  834 | });
  835 | 
  836 | test('deletion review shows list semantics formatting external destinations and canonical passage targets',async({page})=>{
  837 |  const options={failDelete:409};await setup(page,options);await firstNote(page);await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();
  838 |  const passage=await page.evaluate(async()=>{const {parseReference}=await import('/src/lib/passage-references.ts');return parseReference('Genesis 2:1');});
  839 |  const remote={document:{version:2,blocks:[{type:'list',style:'ordered',items:[[{type:'paragraph',direction:'rtl',content:[{type:'text',text:'First item',marks:['bold']},{type:'external_link',url:'https://example.org/new-destination',content:[{type:'text',text:'Same link label',marks:['italic']}]}]}],[{type:'paragraph',direction:'auto',content:[{type:'passage_link',label:'Same passage label',reference:passage}]}]]},{type:'list',style:'bullet',items:[[{type:'paragraph',direction:'auto',content:[{type:'text',text:'Bullet item',marks:[]}]}]]}]},connections:[],highlights:[]};
  840 |  await page.route('**/api/studies/'+study+'/notes/'+note,r=>r.request().method()==='GET'?r.fulfill({json:{...attribution,id:note,study_id:study,visibility:'study',revision:'2',value:remote}}):r.fallback());
  841 |  await page.getByRole('button',{name:'Review current note',exact:true}).click();const review=page.getByRole('region',{name:'Current saved note',exact:true});await expect(review.locator('ol>li')).toHaveCount(2);await expect(review.locator('ul>li')).toHaveCount(1);await expect(review.locator('p[dir="rtl"] strong')).toHaveText('First item');await expect(review.locator('em')).toHaveText('Same link label');await expect(review).toContainText('https://example.org/new-destination');await expect(review).toContainText('Same passage label');await expect(review).toContainText('Genesis 2:1');expect(await review.locator('a').count()).toBe(0);
  842 | });
  843 | 
  844 | test('deletion recovery labels distinguish two retained targets and recover their own operations',async({page})=>{
  845 |  const options={failDelete:503};const {requests}=await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('First target');await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Deletion not confirmed');await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();await page.getByRole('button',{name:'Back to Studies',exact:true}).click();
  846 |  const other='40000000-0000-4000-8000-000000000002',secondValue={document:{version:1,blocks:[{type:'paragraph',direction:'auto',content:[{type:'text',text:'Second target',marks:[]}]}]},connections:[],highlights:[]};let recover=false;const secondDeletes=[];
  847 |  await page.route('**/api/studies/'+study+'/notes',r=>r.request().method()==='POST'?r.fulfill({json:{operation_id:r.request().postDataJSON().operation_id,command:'note.create',study_id:study,note_id:other,revision:'1'}}):r.fallback());
  848 |  await page.route('**/api/studies/'+study+'/notes/'+other,r=>{if(r.request().method()==='DELETE'){const payload=r.request().postDataJSON();secondDeletes.push(payload);return recover?r.fulfill({json:{operation_id:payload.operation_id,command:'note.delete',study_id:study,note_id:other,revision:'2'}}):r.fulfill({status:503,json:{code:'studies_storage_unavailable'}});}return r.fulfill({json:{...attribution,id:other,study_id:study,visibility:'study',revision:'1',value:secondValue}});});
  849 |  await page.getByRole('button',{name:'Add note',exact:true}).click();await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('Deletion not confirmed');await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();
  850 |  const first=page.getByRole('button',{name:/^Recover deletion:.*First target/}),second=page.getByRole('button',{name:/^Recover deletion:.*Second target/});await expect(first).toBeVisible();await expect(second).toBeVisible();expect(await first.textContent()).not.toBe(await second.textContent());
  851 |  recover=true;await second.click();await expect(page.getByRole('dialog')).toContainText('Second target');await page.getByRole('button',{name:'Retry deletion',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(first).toBeVisible();options.failDelete=0;await first.click();await expect(page.getByRole('dialog')).toContainText('First target');await page.getByRole('button',{name:'Retry deletion',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  852 |  const firstDeletes=requests.filter(r=>r.method==='DELETE');expect(firstDeletes).toHaveLength(2);expect(firstDeletes[0].payload).toEqual(firstDeletes[1].payload);expect(secondDeletes).toHaveLength(2);expect(secondDeletes[0]).toEqual(secondDeletes[1]);expect(secondDeletes[0].operation_id).not.toBe(firstDeletes[0].payload.operation_id);
  853 | });
  854 | 
  855 | test('deletion selected target acknowledgement focuses visible fallback when editor is hidden',async({page})=>{
  856 |  let release;await setup(page,{beforeDelete:()=>new Promise(resolve=>release=resolve)});await firstNote(page);await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect.poll(()=>!!release).toBe(true);await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();await page.getByRole('button',{name:'Back to Studies',exact:true}).click();
  857 |  const lateReply=page.waitForResponse(r=>r.request().method()==='DELETE');release();await (await lateReply).finished();await expect(page.getByText('Note deleted.',{exact:true})).toBeVisible();await expect(page.getByText('Note deleted.',{exact:true})).toBeFocused();await expect(page.getByRole('button',{name:'Add note',exact:true})).toBeVisible();
  858 | });
  859 | 
  860 | test('deletion review wraps the full long valid destination within desktop and mobile dialog width',async({page})=>{
  861 |  await setup(page,{failDelete:409});await firstNote(page);await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();
  862 |  const url='https://example.org/new-destination?query='+'a'.repeat(1900),remote={document:{version:1,blocks:[{type:'paragraph',direction:'auto',content:[{type:'external_link',url,content:[{type:'text',text:'Saved destination',marks:[]}]}]}]},connections:[],highlights:[]};
  863 |  await page.route('**/api/studies/'+study+'/notes/'+note,r=>r.request().method()==='GET'?r.fulfill({json:{...attribution,id:note,study_id:study,visibility:'study',revision:'2',value:remote}}):r.fallback());await page.getByRole('button',{name:'Review current note',exact:true}).click();const review=page.getByRole('region',{name:'Current saved note',exact:true});await expect(review).toContainText(url);
  864 |  const widths=await page.getByRole('dialog').evaluate(dialog=>{const content=dialog.querySelector('[aria-label="Current saved note"]');return {dialog:dialog.scrollWidth<=dialog.clientWidth,review:content.scrollWidth<=content.clientWidth,viewport:dialog.getBoundingClientRect().left>=0&&dialog.getBoundingClientRect().right<=innerWidth};});expect(widths).toEqual({dialog:true,review:true,viewport:true});
  865 | });
  866 | 
  867 | for(const destination of ['reader after tools close','surviving public control'])test('deletion acknowledgement preserves deliberate focus on '+destination,async({page})=>{
  868 |  let release;await setup(page,{beforeDelete:()=>new Promise(resolve=>release=resolve)});await firstNote(page);await page.getByRole('button',{name:'Delete note',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Delete note',exact:true}).click();await expect.poll(()=>!!release).toBe(true);await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).click();
  869 |  const mobile=test.info().project.name==='mobile';
  870 |  if(destination==='reader after tools close')await page.getByRole('button',{name:mobile?'Return to reader':'Analysis',exact:true}).click();
  871 |  const control=destination==='surviving public control'&&mobile?page.getByRole('button',{name:'Add reader pane',exact:true}):page.getByRole('button',{name:/^Navigate: Genesis, chapter 1/});await expect(control).toBeVisible();await control.focus();await expect(control).toBeFocused();
  872 |  const acknowledgement=page.waitForResponse(r=>r.request().method()==='DELETE');release();await (await acknowledgement).finished();await expect(page.getByLabel('Note text',{exact:true})).toHaveCount(0);await page.evaluate(()=>new Promise(requestAnimationFrame));await expect(control).toBeFocused();await expect(page.getByText('Note deleted.',{exact:true})).toHaveCount(0);
  873 | });
  874 | 
  875 | test('whole-study deletion confirms captured owned scope and Cancel preserves unsent writing',async({page})=>{
  876 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Unsent study writing');const dialog=await openWholeDeletion(page);await expect(dialog.getByRole('button',{name:'Cancel',exact:true})).toBeFocused();await page.waitForTimeout(650);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(0);await dialog.getByRole('button',{name:'Cancel',exact:true}).click();await expect(editor).toContainText('Unsent study writing');await expect.poll(()=>requests.filter(r=>r.method==='PUT').length).toBe(1);expect(requests.find(r=>r.method==='PUT').payload.value.document.blocks[0].content[0].text).toBe('Unsent study writing');expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(0);
  877 | });
  878 | 
  879 | async function openWholeDeletion(page){await page.getByRole('button',{name:'Delete study',exact:true}).filter({visible:true}).click();return page.getByRole('dialog',{name:'Delete this study?',exact:true});}
  880 | async function confirmWholeDeletion(page){const dialog=await openWholeDeletion(page);await expect(dialog.getByRole('button',{name:'Delete study',exact:true})).toBeEnabled();await dialog.getByRole('button',{name:'Delete study',exact:true}).click();return dialog;}
  881 | async function firstNoteWithPausedClock(page){
  882 |  await page.clock.install();await firstNote(page);
  883 |  // Pause before editing: automation/render latency must not consume the
  884 |  // coordinator's budget. runFor exercises the application's real timer callbacks.
  885 |  await page.clock.pauseAt(await page.evaluate(()=>Date.now()+1000));
  886 | }
  887 | 
  888 | 
  889 | test('whole-study deletion discards dirty writing only after acknowledgement without save',async({page})=>{
  890 |  let release;const {requests}=await setup(page,{beforeStudyDelete:()=>new Promise(resolve=>release=resolve)});await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('Unsent private text');const dialog=await confirmWholeDeletion(page);await expect.poll(()=>!!release).toBe(true);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(0);await expect(editor).toContainText('Unsent private text');release();await expect(dialog).toHaveCount(0);await expect(editor).toHaveCount(0);await expect(page.getByText('Study deleted.',{exact:true})).toBeFocused();expect(requests.filter(r=>r.method==='DELETE')).toHaveLength(1);
  891 | });
```