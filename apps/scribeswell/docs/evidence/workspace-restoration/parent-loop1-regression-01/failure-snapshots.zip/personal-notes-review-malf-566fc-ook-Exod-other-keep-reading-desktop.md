# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personal-notes.spec.cjs >> review: malformed Add Cancel retains unresolved provenance across replay and refresh until valid choice ?reader=%7B%7D&book=Exod&other=keep#reading
- Location: tests/personal-notes.spec.cjs:1149:118

# Error details

```
Error: page.evaluate: Target page, context or browser has been closed
```

# Test source

```ts
  1070 |         saved = window.__fourCaret;
  1071 |       return range ? {
  1072 |         sameStart: range.startContainer === saved.startContainer,
  1073 |         start: range.startOffset,
  1074 |         sameEnd: range.endContainer === saved.endContainer,
  1075 |         end: range.endOffset
  1076 |       } : null;
  1077 |     })).toEqual({
  1078 |       sameStart: true,
  1079 |       start: rangeMode === 'caret' ? 5 : 2,
  1080 |       sameEnd: true,
  1081 |       end: rangeMode === 'caret' ? 5 : 8
  1082 |     });
  1083 |   }
  1084 |   await addReader(page);
  1085 |   await assertCaret();
  1086 |   await page.goBack();
  1087 |   await assertCaret();
  1088 |   await page.goForward();
  1089 |   await assertCaret();
  1090 |   if (page.viewportSize().width < 768) await page.getByRole('button', {
  1091 |     name: 'Return to reader',
  1092 |     exact: true
  1093 |   }).click();
  1094 |   await page.getByRole('button', {
  1095 |     name: 'Close passage 2',
  1096 |     exact: true
  1097 |   }).click();
  1098 |   if (!(await editor.isVisible())) await page.getByRole('button', {
  1099 |     name: 'Analysis',
  1100 |     exact: true
  1101 |   }).click();
  1102 |   await expect(editor).toContainText('composing עברית');
  1103 |   await assertCaret();
  1104 |   expect(await editor.evaluate(el => el === window.__fourEditor && el.querySelector('[data-note-passage]') === window.__fourAtom)).toBe(true);
  1105 |   await page.waitForTimeout(650);
  1106 |   expect(requests.filter(r => r.method === 'PUT')).toHaveLength(writes);
  1107 |   await editor.dispatchEvent('compositionend');
  1108 |   await assertCaret();
  1109 |   await expect(page.getByRole('status').filter({
  1110 |     hasText: 'Draft saved'
  1111 |   })).toBeVisible();
  1112 |   await assertCaret();
  1113 |   expect(requests.filter(r => r.method === 'POST' && r.path.endsWith('/notes'))).toHaveLength(1);
  1114 | });
  1115 | test('four-pane public transitions preserve an unknown original save operation', async ({
  1116 |   page
  1117 | }) => {
  1118 |   const options = {
  1119 |     failPut: 503
  1120 |   };
  1121 |   const {
  1122 |     requests
  1123 |   } = await setup(page, options);
  1124 |   await firstNote(page);
  1125 |   const editor = page.getByLabel('Note text', {
  1126 |     exact: true
  1127 |   });
  1128 |   await editor.fill('Original frozen save');
  1129 |   await expect(page.getByRole('status').filter({
  1130 |     hasText: 'Changes not saved'
  1131 |   })).toBeVisible();
  1132 |   const original = structuredClone(requests.find(r => r.method === 'PUT').payload);
  1133 |   await editor.evaluate(el => window.__fourEditor = el);
  1134 |   await addReader(page);
  1135 |   await page.goBack();
  1136 |   await page.goForward();
  1137 |   await expect(editor).toContainText('Original frozen save');
  1138 |   expect(await editor.evaluate(el => el === window.__fourEditor)).toBe(true);
  1139 |   options.failPut = 0;
  1140 |   await page.getByRole('button', {
  1141 |     name: 'Retry',
  1142 |     exact: true
  1143 |   }).click();
  1144 |   await expect(page.getByRole('status').filter({
  1145 |     hasText: 'Draft saved'
  1146 |   })).toBeVisible();
  1147 |   expect(requests.filter(r => r.method === 'PUT').map(r => r.payload)).toEqual([original, original]);
  1148 | });
  1149 | for (const malformed of ['?book=Gen&chapter=bad&other=keep#reading', '?reader=%7B%7D&book=Exod&other=keep#reading']) test(`review: malformed Add Cancel retains unresolved provenance across replay and refresh until valid choice ${malformed}`, async ({
  1150 |   page
  1151 | }) => {
  1152 |   await setup(page);
  1153 |   await page.goto('/' + malformed);
  1154 |   const original = page.url();
  1155 |   await page.getByRole('button', {
  1156 |     name: 'Studies',
  1157 |     exact: true
  1158 |   }).click();
  1159 |   await page.getByRole('button', {
  1160 |     name: 'Start a study',
  1161 |     exact: true
  1162 |   }).click();
  1163 |   await page.getByRole('button', {
  1164 |     name: 'Create study',
  1165 |     exact: true
  1166 |   }).click();
  1167 |   const idx = await page.evaluate(() => history.state.idx);
  1168 |   await addReader(page);
  1169 |   expect(page.url()).toBe(original);
> 1170 |   expect(await page.evaluate(() => history.state.idx)).toBe(idx + 1);
       |                     ^ Error: page.evaluate: Target page, context or browser has been closed
  1171 |   await expect(page.locator('[data-reader-pane]')).toHaveCount(2);
  1172 |   await expect(page.getByRole('button', {
  1173 |     name: 'Add current passage',
  1174 |     exact: true
  1175 |   })).toHaveCount(0);
  1176 |   await expect(page.getByRole('button', {
  1177 |     name: 'Add passage',
  1178 |     exact: true
  1179 |   })).toBeEnabled();
  1180 |   await page.goBack();
  1181 |   await expect(page.locator('[data-reader-pane]')).toHaveCount(1);
  1182 |   await page.goForward();
  1183 |   await expect(page.locator('[data-reader-pane]')).toHaveCount(2);
  1184 |   await expect(page.getByRole('button', {
  1185 |     name: 'Add current passage',
  1186 |     exact: true
  1187 |   })).toHaveCount(0);
  1188 |   await page.goBack();
  1189 |   await expect(page.locator('[data-reader-pane]')).toHaveCount(1);
  1190 |   await page.goForward();
  1191 |   await expect(page.locator('[data-reader-pane]')).toHaveCount(2);
  1192 |   await expect(page.getByRole('button', {
  1193 |     name: 'Add current passage',
  1194 |     exact: true
  1195 |   })).toHaveCount(0);
  1196 |   await page.reload();
  1197 |   expect(page.url()).toBe(original);
  1198 |   await expect(page.locator('[data-reader-pane]')).toHaveCount(2);
  1199 |   await page.getByRole('button', {
  1200 |     name: 'Studies',
  1201 |     exact: true
  1202 |   }).click();
  1203 |   await page.getByRole('button', {
  1204 |     name: 'Untitled study',
  1205 |     exact: true
  1206 |   }).click();
  1207 |   await expect(page.getByRole('button', {
  1208 |     name: 'Add current passage',
  1209 |     exact: true
  1210 |   })).toHaveCount(0);
  1211 |   if (page.viewportSize().width < 768) await page.getByRole('button', {
  1212 |     name: 'Return to reader',
  1213 |     exact: true
  1214 |   }).click();
  1215 |   await page.locator('[data-reader-pane]').nth(1).getByRole('button', {
  1216 |     name: /Navigate:/
  1217 |   }).click();
  1218 |   await page.getByLabel('Passage reference', {
  1219 |     exact: true
  1220 |   }).fill('Genesis 2');
  1221 |   await page.getByLabel('Passage reference', {
  1222 |     exact: true
  1223 |   }).press('Enter');
  1224 |   expect(new URL(page.url()).searchParams.has('reader')).toBe(true);
  1225 |   expect(new URL(page.url()).searchParams.get('other')).toBe('keep');
  1226 |   expect(new URL(page.url()).hash).toBe('#reading');
  1227 |   if ((await page.getByRole('button', {
  1228 |     name: 'Studies',
  1229 |     exact: true
  1230 |   }).getAttribute('aria-pressed')) !== 'true') await page.getByRole('button', {
  1231 |     name: 'Studies',
  1232 |     exact: true
  1233 |   }).click();
  1234 |   await expect(page.getByRole('button', {
  1235 |     name: 'Add current passage',
  1236 |     exact: true
  1237 |   })).toBeVisible();
  1238 | });
  1239 | test('review: malformed capacity Add replacement Cancel still requires a valid passage choice', async ({
  1240 |   page
  1241 | }) => {
  1242 |   await setup(page);
  1243 |   await page.goto('/?chapter=bad');
  1244 |   const original = page.url();
  1245 |   for (let i = 0; i < 3; i++) await addReader(page);
  1246 |   await page.getByRole('button', {
  1247 |     name: 'Add reader pane',
  1248 |     exact: true
  1249 |   }).click();
  1250 |   await page.getByRole('dialog', {
  1251 |     name: 'Choose passage to replace'
  1252 |   }).getByRole('button', {
  1253 |     name: 'Replace passage 1: Genesis 1',
  1254 |     exact: true
  1255 |   }).click();
  1256 |   await page.getByRole('dialog', {
  1257 |     name: 'Book and chapter selector'
  1258 |   }).getByRole('button', {
  1259 |     name: 'Cancel',
  1260 |     exact: true
  1261 |   }).click();
  1262 |   expect(page.url()).toBe(original);
  1263 |   await page.reload();
  1264 |   await expect(page.locator('[data-reader-pane]')).toHaveCount(4);
  1265 |   await page.getByRole('button', {
  1266 |     name: 'Studies',
  1267 |     exact: true
  1268 |   }).click();
  1269 |   await page.getByRole('button', {
  1270 |     name: 'Start a study',
```