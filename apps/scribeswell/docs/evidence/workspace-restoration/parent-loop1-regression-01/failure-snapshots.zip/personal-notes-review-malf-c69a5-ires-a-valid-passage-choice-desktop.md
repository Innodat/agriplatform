# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: personal-notes.spec.cjs >> review: malformed capacity Add replacement Cancel still requires a valid passage choice
- Location: tests/personal-notes.spec.cjs:1239:1

# Error details

```
Error: locator.click: Test ended.
Call log:
  - waiting for getByRole('dialog', { name: 'Book and chapter selector' }).getByRole('button', { name: 'Cancel', exact: true })
    - locator resolved to <button type="button" class="underline text-sm mt-1">Cancel</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling

```

# Test source

```ts
  1   | // Project the new public wire into coordinates for existing behavioral assertions.
  2   | // Deliberate navigation now emits only reader; incoming legacy links stay covered.
  3   | function readerParams(href) {
  4   |   const params = new URL(href).searchParams;
  5   |   if (!params.has('reader')) return params;
  6   |   const layout = JSON.parse(params.get('reader')),
  7   |     out = new URLSearchParams();
  8   |   layout.panes.forEach(({
  9   |     ref
  10  |   }, index) => {
  11  |     const start = ref.target.kind === 'chapter' ? {
  12  |         chapter: ref.target.chapter
  13  |       } : ref.target.start,
  14  |       prefix = index ? 'compare' : '';
  15  |     out.set(index ? 'compareBook' : 'book', ref.book_id);
  16  |     out.set(index ? 'compareChapter' : 'chapter', String(start.chapter));
  17  |     if (start.verse) {
  18  |       out.set(index ? 'compareVerse' : 'verse', String(start.verse));
  19  |       out.set(prefix + 'EndChapter', String(ref.target.end.chapter));
  20  |       out.set(prefix + 'EndVerse', String(ref.target.end.verse));
  21  |     }
  22  |   });
  23  |   return out;
  24  | }
  25  | async function addReader(page) {
  26  |   const tool = (await page.getByRole('button', {
  27  |     name: 'Analysis',
  28  |     exact: true
  29  |   }).getAttribute('aria-pressed')) === 'true' ? 'Analysis' : (await page.getByRole('button', {
  30  |     name: 'Studies',
  31  |     exact: true
  32  |   }).getAttribute('aria-pressed')) === 'true' ? 'Studies' : null;
  33  |   await page.getByRole('button', {
  34  |     name: 'Add reader pane',
  35  |     exact: true
  36  |   }).click();
  37  |   await page.getByRole('dialog', {
  38  |     name: 'Book and chapter selector'
  39  |   }).getByRole('button', {
  40  |     name: 'Cancel',
  41  |     exact: true
> 42  |   }).click();
      |      ^ Error: locator.click: Test ended.
  43  |   if (tool && page.viewportSize().width < 768) await page.getByRole('button', {
  44  |     name: tool,
  45  |     exact: true
  46  |   }).click();
  47  | }
  48  | const {test,expect}=require('@playwright/test');
  49  | const account='10000000-0000-4000-8000-000000000001',actor='20000000-0000-4000-8000-000000000001';
  50  | const study='30000000-0000-4000-8000-000000000001',note='40000000-0000-4000-8000-000000000001';
  51  | const session={access_token:'current',refresh_token:'fixture',expires_at:Date.now()/1000+3600,expires_in:3600,token_type:'bearer',user:{id:account,email:'reader@example.invalid',aud:'authenticated',app_metadata:{},user_metadata:{}}};
  52  | const attribution={owner_account_id:account,created_at:'2026-10-23T10:00:00.000000Z',updated_at:'2026-10-23T10:00:00.000000Z',created_by_actor_id:actor,updated_by_actor_id:actor};
  53  | async function setup(page,options={}){
  54  |  await page.route('**/auth/v1/user*',async r=>{const user=await page.evaluate(()=>{const value=localStorage.getItem('pts-auth');return value?JSON.parse(value).user:null;});return r.fulfill(user?{json:user}:{status:401,json:{error_code:'session_not_found',msg:'Synthetic session unavailable'}});});
  55  |  await page.route('**/auth/v1/logout*',r=>r.fulfill({json:{}}));
  56  |  await page.addInitScript(s=>localStorage.setItem('pts-auth',JSON.stringify(s)),session);
  57  |  await page.route('http://127.0.0.1:8001/**',r=>r.fulfill({json:[]}));
  58  |  await page.route('**/api/bible/**',r=>{const path=new URL(r.request().url()).pathname;const b={id:1,osis_id:'Gen',name_en:'Genesis',name_he:'בראשית',testament:'OT',book_order:1};const w={id:1,position:1,surface_he:'בְּרֵאשִׁית',display_he:'בְּרֵאשִׁית',lemma_strong:null,morph_code:null};return r.fulfill({json:path.endsWith('/books')?{data:[b],total:1}:path.endsWith('/books/Gen')?{...b,chapters:[{id:1,chapter_num:1}]}:path.includes('/words/')?{...w,morphemes:[]}:{data:[{id:1,verse_num:1,book_id:1,chapter_num:1,words:[w]}],total:1}});});
  59  |  const collection={study_id:study,revision:'1',items:[]};
  60  |  const metadata={title:'Untitled study',revision:'1'};
  61  |  let saved={document:{version:1,blocks:[]},connections:[],highlights:[]},created=false,noteCreated=false,revision='1',requests=[],operations=new Map();
  62  |  await page.route('**/api/operations/**',async r=>{if(options.beforeLookup)await options.beforeLookup();const id=new URL(r.request().url()).pathname.split('/').pop();return r.fulfill({json:options.unresolved?{status:'unresolved'}:operations.has(id)?{status:'committed',outcome:operations.get(id)}:{status:'unresolved'}});});
  63  |  await page.route('**/api/studies**',async r=>{
  64  |   const req=r.request(),url=new URL(req.url()),path=url.pathname,method=req.method(),payload=req.postDataJSON();requests.push({path,method,payload});
  65  |   let data;
  66  |   if(path.endsWith('/search')){if(options.search)return options.search(r,payload);data={items:created?[{...attribution,id:study,title:metadata.title,revision:metadata.revision}]:[],next_cursor:null};}
  67  |   else if(path.endsWith('/enrollment'))data={operation_id:payload.operation_id,status:'committed',result:{disposition:'created',account_id:account,actor_id:actor,permission:'scribeswell.studies.use'}};
  68  |   else if(path.endsWith('/passages')){
  69  |    if(method==='GET'){
  70  |     if(options.beforePassageRead)await options.beforePassageRead();
  71  |     if(options.failPassageRead)return r.fulfill({status:503,json:{code:'studies_storage_unavailable'}});
  72  |     data=collection;
  73  |    }else{
  74  |     if(options.beforePassagePut)await options.beforePassagePut();
  75  |     if(options.failPassages)return r.fulfill({status:options.failPassages,json:{code:options.failPassages===409?'passage_revision_conflict':options.failPassages===400?'scribeswell_personal_notes_input_invalid':options.failPassages===401?'authentication_required':options.failPassages===403?'studies_access_denied':options.failPassages===404?'resource_unavailable':'studies_storage_unavailable'}});
  76  |     if(operations.has(payload.operation_id))data=operations.get(payload.operation_id);
  77  |     else{if(payload.expected_revision!==collection.revision)return r.fulfill({status:409,json:{code:'passage_revision_conflict'}});if(JSON.stringify(payload.items)!==JSON.stringify(collection.items)){collection.items=payload.items;collection.revision=String(Number(collection.revision)+1);}data={operation_id:payload.operation_id,command:'study.passages.replace',study_id:study,note_id:null,revision:collection.revision};operations.set(payload.operation_id,data);}
  78  |     if(options.afterPassageCommit)options.afterPassageCommit();
  79  |     if(options.dropPassages){options.dropPassages=false;return r.abort('connectionreset');}
  80  |    }
  81  |   }
  82  |   else if(path.endsWith('/title')&&method==='PUT'){
  83  |    if(options.beforeRename)await options.beforeRename();
  84  |    if(options.failRename)return r.fulfill({status:options.failRename,json:{code:options.failRename===409?'study_revision_conflict':options.failRename===400?'scribeswell_personal_notes_input_invalid':options.failRename===401?'authentication_required':options.failRename===403?'studies_access_denied':'studies_storage_unavailable'}});
  85  |    if(operations.has(payload.operation_id))data=operations.get(payload.operation_id);
  86  |    else{if(metadata.title!==payload.title){metadata.title=payload.title;metadata.revision=String(Number(metadata.revision)+1);}data={operation_id:payload.operation_id,command:'study.rename',study_id:study,note_id:null,revision:metadata.revision};operations.set(payload.operation_id,data);}
  87  |    if(options.dropRename){options.dropRename=false;return r.abort('connectionreset');}
  88  |   }
  89  |   else if(path.endsWith('/'+study)&&method==='DELETE'){
  90  |    if(options.beforeStudyDelete)await options.beforeStudyDelete();
  91  |    if(options.failStudyDelete)return r.fulfill({status:options.failStudyDelete,json:{code:options.failStudyDeleteCode??(options.failStudyDelete===409?'study_revision_conflict':options.failStudyDelete===401?'authentication_required':options.failStudyDelete===403?'studies_access_denied':'studies_storage_unavailable')}});
  92  |    if(operations.has(payload.operation_id))data=operations.get(payload.operation_id);
  93  |    else{if(payload.expected_revision!==metadata.revision)return r.fulfill({status:409,json:{code:'study_revision_conflict'}});metadata.revision=String(Number(metadata.revision)+1);metadata.title='Deleted study';created=false;noteCreated=false;saved={document:{version:1,blocks:[]},connections:[],highlights:[]};collection.items=[];data={operation_id:payload.operation_id,command:'study.delete',study_id:study,note_id:null,revision:metadata.revision};operations.set(payload.operation_id,data);}
  94  |    if(options.dropStudyDelete){options.dropStudyDelete=false;return r.abort('connectionreset');}
  95  |   }
  96  |   else if(path.endsWith('/notes/'+note)&&method==='DELETE'){
  97  |    if(options.beforeDelete)await options.beforeDelete();
  98  |    if(options.failDelete)return r.fulfill({status:options.failDelete,json:{code:options.failDeleteCode??(options.failDelete===409?'note_revision_conflict':options.failDelete===401?'authentication_required':options.failDelete===403?'studies_access_denied':'studies_storage_unavailable')}});
  99  |    if(operations.has(payload.operation_id))data=operations.get(payload.operation_id);
  100 |    else{if(payload.expected_revision!==revision)return r.fulfill({status:409,json:{code:'note_revision_conflict'}});revision=String(Number(revision)+1);saved={document:{version:1,blocks:[]},connections:[],highlights:[]};noteCreated=false;data={operation_id:payload.operation_id,command:'note.delete',study_id:study,note_id:note,revision};operations.set(payload.operation_id,data);}
  101 |    if(options.dropDelete){options.dropDelete=false;return r.abort('connectionreset');}
  102 |   }
  103 |   else if(path.endsWith('/notes/'+note)&&method==='PUT'){if(options.beforePut)await options.beforePut();if(options.failPut)return r.fulfill({status:options.failPut,json:{code:options.failPutCode??(options.failPut===409?'note_revision_conflict':options.failPut===401?'authentication_required':options.failPut===403?'studies_access_denied':'studies_storage_unavailable')}});saved=payload.value;revision=String(Number(revision)+1);data={operation_id:payload.operation_id,command:'note.replace',study_id:study,note_id:note,revision};}
  104 |   else if(path.endsWith('/notes/'+note))data={...attribution,id:note,study_id:study,visibility:'study',value:saved,revision};
  105 |   else if(path.endsWith('/notes')&&method==='POST'){noteCreated=true;saved=options.noteValue??payload.value;data={operation_id:payload.operation_id,command:'note.create',study_id:study,note_id:note,revision};}
  106 |   else if(path.endsWith('/notes'))data={items:noteCreated?[{...attribution,id:note,study_id:study,visibility:'study',value:saved,revision}]:[],next_cursor:null};
  107 |   else if(method==='POST'){created=true;data={operation_id:payload.operation_id,command:'study.create',study_id:study,note_id:null,revision:'1'};}
  108 |   else if(path.endsWith('/'+study)){if(options.beforeStudyRead)await options.beforeStudyRead();data={...attribution,id:study,title:metadata.title,revision:metadata.revision};}
  109 |   else data={items:created?[{...attribution,id:study,title:metadata.title,revision:metadata.revision}]:[],next_cursor:null};
  110 |   if(data.command)operations.set(data.operation_id,data);
  111 |   if(method==='PUT'&&options.dropPut){options.dropPut=false;return r.abort('connectionreset');}
  112 |   return r.fulfill({json:data,headers:{'cache-control':'private, no-store'}});
  113 |  });return {requests,metadata,collection,advanceNote:(value)=>{saved=value;revision=String(Number(revision)+1);}};
  114 | }
  115 | test('explicitly enroll, create, write Hebrew and reopen saved text after reload',async({page})=>{
  116 |  const {requests}=await setup(page);await page.goto('/');expect(requests).toHaveLength(0);
  117 |  await page.getByRole('button',{name:'Studies',exact:true}).click();
  118 |  await page.getByRole('button',{name:'Start a study',exact:true}).click();
  119 |  await page.getByRole('button',{name:'Create study',exact:true}).click();
  120 |  await expect(page.getByRole('heading',{name:'Untitled study',exact:true})).toBeVisible();
  121 |  await page.getByRole('button',{name:'Add note',exact:true}).click();
  122 |  await page.getByLabel('Note text',{exact:true}).fill('בְּרֵאשִׁית — personal observation');
  123 |  await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();
  124 |  await page.reload();await page.getByRole('button',{name:'Studies',exact:true}).click();
  125 |  await page.getByRole('button',{name:'Untitled study',exact:true}).click();
  126 |  await page.getByRole('button',{name:/personal observation/}).click();
  127 |  await expect(page.getByLabel('Note text',{exact:true})).toContainText('בְּרֵאשִׁית — personal observation');
  128 |  expect(requests.filter(r=>r.path.endsWith('/enrollment'))).toHaveLength(1);
  129 | });
  130 | 
  131 | async function firstNote(page){await page.goto('/');await page.getByRole('button',{name:'Studies',exact:true}).click();await page.getByRole('button',{name:'Start a study',exact:true}).click();await page.getByRole('button',{name:'Create study',exact:true}).click();await page.getByRole('button',{name:'Add note',exact:true}).click();await expect(page.getByLabel('Note text',{exact:true})).toBeVisible();}
  132 | test('failed saves use inline Retry and exit-only Stay / Close anyway',async({page})=>{
  133 |  const options={failPut:503};await setup(page,options);await firstNote(page);await page.getByLabel('Note text',{exact:true}).fill('Unsaved Hebrew שָׁלוֹם');await expect(page.getByRole('status').filter({hasText:'Changes not saved'})).toBeVisible();await expect(page.getByRole('button',{name:'Keep editing'})).toHaveCount(0);await expect(page.getByRole('dialog')).toHaveCount(0);
  134 |  await page.getByRole('button',{name:'Sign out',exact:true}).click();await expect(page.getByRole('dialog',{name:'Changes not saved'})).toBeVisible();await page.getByRole('button',{name:'Stay',exact:true}).click();await expect(page.getByLabel('Note text',{exact:true})).toContainText('שָׁלוֹם');options.failPut=0;await page.getByRole('button',{name:'Retry',exact:true}).click();await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();await page.getByRole('button',{name:'Sign out',exact:true}).click();await expect(page.getByRole('dialog',{name:'Changes not saved'})).toHaveCount(0);
  135 | });
  136 | test('delayed old acknowledgement cannot mark newer text saved',async({page})=>{
  137 |  let release;const options={beforePut:()=>new Promise(resolve=>release=resolve)};const {requests}=await setup(page,options);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.fill('first');await expect.poll(()=>Boolean(release)).toBe(true);await editor.fill('newer שָׁלוֹם');await expect(page.getByRole('status')).not.toHaveText('Draft saved');expect(requests.filter(r=>r.method==='PUT')).toHaveLength(1);options.beforePut=undefined;release();await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();expect(requests.filter(r=>r.method==='PUT')).toHaveLength(2);await expect(editor).toContainText('newer שָׁלוֹם');
  138 | });
  139 | test('composition defers autosave until IME completion',async({page})=>{
  140 |  const {requests}=await setup(page);await firstNote(page);const editor=page.getByLabel('Note text',{exact:true});await editor.dispatchEvent('compositionstart');await editor.fill('עברית');await page.waitForTimeout(700);expect(requests.filter(r=>r.method==='PUT')).toHaveLength(0);await editor.dispatchEvent('compositionend');await expect.poll(()=>requests.filter(r=>r.method==='PUT').length).toBe(1);await expect(page.getByRole('status').filter({hasText:'Draft saved'})).toBeVisible();
  141 | });
  142 | test('account replacement discards prior private UI and late saves',async({page})=>{
```